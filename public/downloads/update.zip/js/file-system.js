// --- file-system.js ---

function selectFolder(dirPath, element) {
            currentSelectedDir = dirPath;
            document.querySelectorAll('.folder-label').forEach(el => el.classList.remove('active'));
            element.closest('.folder-label').classList.add('active');
            renderGrid();
            
            const currentSize = document.getElementById('size-slider').value;
            changeGridSize(currentSize);
        }

function scanFolderRecursive(dir, depth, parentColor) {
            try {
                const items = fs.readdirSync(dir, { withFileTypes: true });
                const ul = document.createElement('ul');
                ul.className = 'tree-children';
                ul.style.display = 'none'; 
                let hasContent = false;
                
                const mediaBaseNames = items.filter(i => !i.isDirectory() && i.name.match(/\.(mp4|mov|mogrt|wav|mp3)$/i))
                                            .map(i => path.basename(i.name, path.extname(i.name)).toLowerCase());

                // 🌟 แยกส่วน: โฟลเดอร์ 🌟
                const folders = items.filter(i => i.isDirectory() && i.name !== '_Blue Bird Previews');
                const files = items.filter(i => !i.isDirectory());

                folders.forEach(item => {
                    const fullPath = path.join(dir, item.name);
                    hasContent = true;
                    const li = document.createElement('li');
                    li.className = 'tree-node';
                    
                    let ownColor = folderColors[fullPath] || '';
                    let stripColor = ownColor || parentColor || 'transparent';
                    let paddingLeft = 12 + (depth * 15);

                    li.innerHTML = `
                        <div class="folder-label" data-path="${fullPath.replace(/"/g, '&quot;')}" style="border-left-color: ${stripColor}; padding-left: ${paddingLeft}px;" oncontextmenu="showContextMenu(event, '${fullPath.replace(/\\/g, '\\\\').replace(/'/g, "\\'")}', this)">
                            <span class="caret" onclick="toggleNode(this)">▶</span>
                            ${svgFolderIcon}
                            <span class="folder-name" onclick="selectFolder('${fullPath.replace(/\\/g, '\\\\').replace(/'/g, "\\'")}', this)">${item.name}</span>
                        </div>
                    `;
                    const subUl = scanFolderRecursive(fullPath, depth + 1, stripColor);
                    if (subUl) li.appendChild(subUl);
                    else li.querySelector('.caret').style.visibility = 'hidden';
                    ul.appendChild(li);
                });

                // 🌟 แยกส่วน: สร้างรายชื่อไฟล์ 🌟
                files.forEach(item => {
                    const fullPath = path.join(dir, item.name);
                    const ext = path.extname(item.name).toLowerCase();
                    const baseName = path.basename(item.name, ext).toLowerCase();
                    
                    let isMedia = false;
                    let type = '';
                    let badgeClass = '';
                    
                    if (['.wav', '.mp3', '.mogrt', '.mp4', '.mov'].includes(ext)) {
                        isMedia = true;
                        type = (ext === '.mogrt') ? 'Graphics' : (['.mp4', '.mov'].includes(ext) ? 'Video' : 'Audio');
                        badgeClass = (ext === '.mogrt') ? 'badge mogrt' : (['.mp4', '.mov'].includes(ext) ? 'badge video' : 'badge audio');
                    } else if (['.jpg', '.jpeg', '.png'].includes(ext)) {
                        if (!mediaBaseNames.includes(baseName)) {
                            isMedia = true;
                            type = 'Image';
                            badgeClass = 'badge image';
                        }
                    }

                    if (isMedia) {
                        hasContent = true;
                        const fileObj = { name: item.name, fullPath: fullPath, ext: ext, type: type, dir: dir };
                        allFiles.push(fileObj);

                        const li = document.createElement('li');
                        li.className = 'tree-node';
                        
                        let paddingLeft = 12 + (depth * 15) + 22; 

                        li.innerHTML = `
                            <div class="file-label" style="padding-left: ${paddingLeft}px;" title="${item.name}">
                                <span class="${badgeClass}" style="display: inline-block; width: 10px; height: 10px; min-width: 10px; padding: 0; border-radius: 3px; flex-shrink: 0; margin-right: 8px;"></span>
                                <span class="folder-name">${item.name}</span>
                            </div>
                        `;
                        
                        li.onclick = (e) => {
                            e.stopPropagation();
                            
                            currentSelectedDir = dir;
                            document.querySelectorAll('.folder-label').forEach(el => el.classList.remove('active'));
                            const parentLabel = ul.previousElementSibling;
                            if(parentLabel && parentLabel.classList.contains('folder-label')) {
                                parentLabel.classList.add('active');
                            }

                            document.querySelectorAll('.file-label').forEach(el => el.classList.remove('active'));
                            li.querySelector('.file-label').classList.add('active');

                            document.getElementById('search').value = "";
                            renderGrid();

                            // 🚀 แก้บั๊กเว้นวรรคคู่: อ่านจาก getAttribute('title') แทน innerText 🚀
                            const allCards = document.querySelectorAll('.card');
                            let targetCard = null;
                            allCards.forEach(card => {
                                const titleEl = card.querySelector('.card-title');
                                if (titleEl && titleEl.getAttribute('title') === item.name) {
                                    targetCard = card;
                                    card.style.display = 'block'; 
                                } else {
                                    card.style.display = 'none'; 
                                }
                            });
                            
                            if (typeof changeGridSize === "function") {
                                changeGridSize(document.getElementById('size-slider').value);
                            }

                            setTimeout(() => {
                                if(targetCard) {
                                    playAsset(fileObj, targetCard, true);
                                }
                            }, 50);
                        };

                        li.ondblclick = (e) => {
                            e.stopPropagation();
                            addSelectedToTimeline();
                        };

                        ul.appendChild(li);
                    }
                });

                return hasContent ? ul : null;
            } catch (e) { return null; }
        }

function loadSavedFolders() {
            let savedFolders = [];
            try {
                savedFolders = JSON.parse(bluebirdStorage.getItem('bluebird_folders')) || [];
            } catch(e) {}

            const menu = document.getElementById('folder-list');
            menu.innerHTML = '<div class="menu-title">MY LIBRARY</div>';
            allFiles = [];
            
            savedFolders.forEach(dirPath => {
                if (fs.existsSync(dirPath)) {
                    const folderName = path.basename(dirPath);
                    const rootNode = document.createElement('div');
                    rootNode.className = 'tree-root';
            
                    let ownColor = folderColors[dirPath] || '';
                    let stripColor = ownColor || 'transparent';
                    
                    rootNode.innerHTML = `
                        <div class="folder-label" data-path="${dirPath.replace(/"/g, '&quot;')}" style="border-left-color: ${stripColor}; padding-left: 12px;" oncontextmenu="showContextMenu(event, '${dirPath.replace(/\\/g, '\\\\').replace(/'/g, "\\'")}', this)">
                            <span class="caret caret-down" onclick="toggleNode(this)">▶</span>
                            ${svgFolderIcon}
                            <span class="folder-name" onclick="selectFolder('${dirPath.replace(/\\/g, '\\\\').replace(/'/g, "\\'")}', this)">${folderName}</span>
                        </div>
                    `;
                    const subUl = scanFolderRecursive(dirPath, 1, stripColor);
                    if (subUl) {
                        subUl.style.display = 'block';
                        rootNode.appendChild(subUl);
                    } else {
                        rootNode.querySelector('.caret').style.visibility = 'hidden';
                    }
                    menu.appendChild(rootNode);
                }
            });
            if (currentSelectedDir) {
                renderGrid();
                const currentSize = document.getElementById('size-slider').value;
                changeGridSize(currentSize);
            }
        }

function openNativePicker() {
    // ป้องกันการกดปุ่มรัวๆ
    if (typeof window.isPickerRunning === 'undefined') window.isPickerRunning = false;
    if (window.isPickerRunning) return; 

    const btn = document.querySelector('.add-folder-btn');
    const originalText = btn ? btn.innerHTML : "Add Folder";
    
    if(btn) {
        btn.innerHTML = "⏳ กำลังเปิด...";
        btn.style.opacity = "0.5";
        btn.style.cursor = "not-allowed";
    }
    window.isPickerRunning = true;

    try {
        // 🌟 เรียกใช้พลังของ Adobe Premiere Pro โดยตรง! 🌟
        if (window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx) {
            
            // คำสั่งเรียกหน้าต่าง: (allowMultipleSelection, chooseDirectory, title, initialPath, fileTypes)
            let result = window.cep.fs.showOpenDialogEx(false, true, "เลือกโฟลเดอร์คลังแสง", "", []);

            // ถ้าค่า result.data มีของอยู่ แปลว่าอาจารย์เลือกโฟลเดอร์สำเร็จ (ไม่ได้กดยกเลิก)
            if (result && result.data && result.data.length > 0) {
                let folderPath = result.data[0].replace(/\\/g, '/');
                
                // ส่งโฟลเดอร์ไปให้ระบบกวาดไฟล์ทำงานต่อ
                window.pendingFolderToAdd = folderPath;
                if (typeof startGeneratingPreviews === 'function') {
                    startGeneratingPreviews();
                }
            }
        } else {
            alert("❌ ระบบปลั๊กอินของ Adobe ขัดข้อง ไม่พบคำสั่ง window.cep");
        }
    } catch (err) {
        alert("❌ เกิดข้อผิดพลาด:\n" + err.message);
    } finally {
        // คืนค่าปุ่มให้กลับมาปกติ
        window.isPickerRunning = false;
        if(btn) { 
            btn.innerHTML = originalText; 
            btn.style.opacity = "1"; 
            btn.style.cursor = "pointer"; 
        }
    }
}

function closeCustomPicker() { document.getElementById('custom-picker-modal').style.display = 'none'; }

function renderDrivesList() {
            const tree = document.getElementById('picker-tree');
            tree.innerHTML = `<p style="color:var(--text-light);">กำลังโหลดรายชื่อไดรฟ์...</p>`;
            exec('powershell -Command "Get-PSDrive -PSProvider FileSystem | Select-Object -ExpandProperty Name"', (err, stdout) => {
                let drives = stdout.split('\r\n').map(d => d.trim()).filter(d => d.length > 0);
                if (drives.length === 0) drives = ['C', 'D', 'G']; 
                tree.innerHTML = '<div style="font-weight:bold; margin-bottom:10px; color:var(--text-light);">รายชื่อไดรฟ์:</div>';
                drives.forEach(drive => {
                    const drvPath = drive + ":\\";
                    const item = document.createElement('div');
                    item.className = 'picker-item';
                    item.innerHTML = `💻 <b>Drive ${drive}:</b>`;
                    item.onclick = () => navigatePickerPath(drvPath);
                    tree.appendChild(item);
                });
            });
        }

function handlePathGo() {
            let inputPath = document.getElementById('custom-path-input').value.trim();
            if (!inputPath) return;
            if (fs.existsSync(inputPath)) {
                if (!inputPath.endsWith('\\')) inputPath += '\\';
                navigatePickerPath(inputPath);
            } else { alert("❌ หาโฟลเดอร์ไม่เจอครับ"); }
        }

function navigatePickerPath(targetPath) {
            currentPickerPath = targetPath;
            selectedPathToConfirm = targetPath;
            document.getElementById('custom-path-input').value = targetPath;
            const tree = document.getElementById('picker-tree');
            tree.innerHTML = '';
            const parentDir = path.dirname(targetPath);
            if (parentDir !== targetPath) {
                const backItem = document.createElement('div');
                backItem.className = 'picker-item';
                backItem.style.color = '#eab308';
                backItem.innerHTML = `⬅️ <b>[ ย้อนกลับ ]</b>`;
                backItem.onclick = () => {
                    let nextPath = targetPath.endsWith('\\') ? path.dirname(parentDir) : parentDir;
                    if (!nextPath.endsWith('\\')) nextPath += '\\';
                    navigatePickerPath(nextPath);
                };
                tree.appendChild(backItem);
            }
            try {
                const items = fs.readdirSync(targetPath, { withFileTypes: true });
                items.forEach(item => {
                    if (item.isDirectory()) {
                        // 🚨 ซ่อนโฟลเดอร์พรีวิวไม่ให้โผล่ในหน้าค้นหาด้วย!
                        if (item.name === '_Blue Bird Previews') return; 

                        const fullPath = path.join(targetPath, item.name);
                        const folderDiv = document.createElement('div');
                        folderDiv.className = 'picker-item';
                        folderDiv.innerHTML = `📁 ${item.name}`;
                        folderDiv.ondblclick = () => navigatePickerPath(fullPath + "\\");
                        folderDiv.onclick = (e) => {
                            document.querySelectorAll('.picker-item').forEach(el => el.classList.remove('selected'));
                            folderDiv.classList.add('selected');
                            selectedPathToConfirm = fullPath;
                            document.getElementById('custom-path-input').value = fullPath;
                            e.stopPropagation();
                        };
                        tree.appendChild(folderDiv);
                    }
                });
            } catch (e) {}
        }

function confirmCustomPicker() {
            if (selectedPathToConfirm) {
                document.getElementById('custom-picker-modal').style.display = 'none';
                
                // 🌟 ข้ามหน้าต่างถามไปเลย ตั้งค่าโฟลเดอร์แล้วสั่งเจนพรีวิวทันที 🌟
                window.pendingFolderToAdd = selectedPathToConfirm;
                startGeneratingPreviews();
            }
        }

function startGeneratingPreviews() {
            try { document.getElementById('add-library-dialog').style.display = 'none'; } catch(e){}
            try { document.getElementById('custom-picker-modal').style.display = 'none'; } catch(e){}
            
            const folderPath = window.pendingFolderToAdd;
            if (!folderPath) return;

            const ffmpegPath = path.join(__dirname, 'bin', 'ffmpeg.exe');

            previewQueue = [];
            stopRequested = false;

            // 🌟 1. ฟังก์ชันสร้างคิวพรีวิวแบบ "ทะลุทะลวง (Recursive)" หาไฟล์ในซับโฟลเดอร์ 🌟
            function scanForMediaToPreview(currentDir) {
                            try {
                                const items = fs.readdirSync(currentDir, { withFileTypes: true });
                                items.forEach(item => {
                                    if (item.isDirectory() && item.name !== '_Blue Bird Previews') {
                                        scanForMediaToPreview(path.join(currentDir, item.name));
                                    } else if (!item.isDirectory()) {
                                        const file = item.name;
                                        const ext = path.extname(file).toLowerCase();

                                        if (['.mp4', '.mov', '.mogrt', '.wav', '.mp3', '.png', '.jpg', '.jpeg', '.webp', '.gif', '.m4a', '.aac', '.flac', '.avi', '.mkv', '.webm'].includes(ext)) {
                                            const targetDir = path.join(currentDir, '_Blue Bird Previews');
                                            try { if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir); } catch(err) {}

                                            const inputPath = path.join(currentDir, file);
                                            const baseName = path.basename(file, ext);
                                            const isAudioFile = ['.wav', '.mp3', '.m4a', '.aac', '.flac'].includes(ext); // 👈 พระเอกอยู่ตรงนี้: จับตัวตนว่าเป็นไฟล์เสียง
                                            const isStaticImgFile = ['.png', '.jpg', '.jpeg', '.webp', '.gif'].includes(ext);

                                            let externalPreview = null;

                                            // 🛑 กฎเหล็กข้อ 1: ถ้าเป็นไฟล์เสียง ห้ามดึงวิดีโอชื่อซ้ำมาทำพรีวิวเด็ดขาด!
                                            if (!isAudioFile) {
                                                ['.mp4', '.webm', '.mov'].forEach(vext => {
                                                    const checkPath = path.join(currentDir, baseName + vext);
                                                    if (fs.existsSync(checkPath) && checkPath !== inputPath) externalPreview = checkPath;
                                                });
                                            }

                                            const outputPath = path.join(targetDir, file + '.png');

                                            const mrHorseJpg = path.join(currentDir, file + '.jpg');
                                            const mrHorsePng = path.join(currentDir, file + '.png');
                                            const normalJpg = path.join(currentDir, baseName + '.jpg');
                                            const normalPng = path.join(currentDir, baseName + '.png');

                                            let foundImageTwin = null;
                                            if (fs.existsSync(mrHorseJpg)) foundImageTwin = mrHorseJpg;
                                            else if (fs.existsSync(mrHorsePng)) foundImageTwin = mrHorsePng;
                                            else if (fs.existsSync(normalJpg)) foundImageTwin = normalJpg;
                                            else if (fs.existsSync(normalPng)) foundImageTwin = normalPng;

                                            if (!fs.existsSync(outputPath)) {
                                                if (externalPreview) {
                                                    previewQueue.push({ input: inputPath, external: externalPreview, output: outputPath, file: file, dir: currentDir, type: ext });
                                                } else if (foundImageTwin && !isAudioFile && !isStaticImgFile) {
                                                    // 🛑 กฎเหล็กข้อ 2: ไฟล์เสียงห้ามขโมยรูปภาพมาใช้ ต้องวาดคลื่นเสียงเท่านั้น!
                                                    try { fs.copyFileSync(foundImageTwin, outputPath); } catch(err) {}
                                                } else {
                                                    // ไฟล์เสียงทั้งหมดจะถูกส่งมาเข้าเตาอบวาดคลื่นเสียงที่นี่
                                                    previewQueue.push({ input: inputPath, external: null, output: outputPath, file: file, dir: currentDir, type: ext });
                                                }
                                            }
                                        }
                                    }
                                });
                            } catch(e) {}
                        }
            // สั่งเริ่มค้นหาไฟล์ตั้งแต่โฟลเดอร์หลักที่เลือก
            scanForMediaToPreview(folderPath);

            let savedFolders = [];
            try { savedFolders = JSON.parse(bluebirdStorage.getItem('bluebird_folders')) || []; } catch(e) {}
            if (!savedFolders.includes(folderPath)) {
                savedFolders.push(folderPath);
                bluebirdStorage.setItem('bluebird_folders', JSON.stringify(savedFolders));
                loadSavedFolders(); 
            }

            currentSelectedDir = folderPath;
            setTimeout(() => {
                document.querySelectorAll('.folder-label').forEach(el => {
                    if (el.getAttribute('data-path') === folderPath) {
                        document.querySelectorAll('.folder-label').forEach(l => l.classList.remove('active'));
                        el.classList.add('active');
                    }
                });
            }, 100);

            if (previewQueue.length > 0) {
                document.getElementById('progress-banner').style.display = 'flex';
                updateProgressUI();
                if (!isGenerating) processNextPreview(ffmpegPath);
            } else {
                renderGrid();
                if(typeof changeGridSize === "function") changeGridSize(document.getElementById('size-slider').value);
            }
        }


function updateProgressUI() {
            document.getElementById('preview-remaining').innerText = previewQueue.length + ' remaining';
        }

function stopGenerating() {
            stopRequested = true;
            previewQueue = [];
            isGenerating = false;
            document.getElementById('progress-banner').style.display = 'none';
            renderGrid(); 
            if(typeof changeGridSize === "function") changeGridSize(document.getElementById('size-slider').value);
        }

function safeRemove(dirPath) {
            try {
                if (fs.rmSync) { fs.rmSync(dirPath, { recursive: true, force: true }); }
                else if (fs.rmdirSync) { fs.rmdirSync(dirPath, { recursive: true }); }
            } catch(e) {
                exec(`powershell -Command "Remove-Item -Recurse -Force '${dirPath.replace(/'/g, "''")}'"`); 
            }
        }

function getAerenderPath() {
            // 1. เช็คก่อนว่าลูกค้าเคยตั้งค่าเองไว้ไหม
            let savedPath = bluebirdStorage.getItem('bluebird_aerender_path');
            if (savedPath && fs.existsSync(savedPath)) return `"${savedPath}"`;

            // 2. ลิสต์ไดรฟ์ยอดฮิตที่คนมักจะติดตั้งโปรแกรม
            const possibleDrives = ["C:", "D:", "E:", "F:"];
            
            for (let drive of possibleDrives) {
                const adobePath = drive + "\\Program Files\\Adobe";
                
                if (fs.existsSync(adobePath)) {
                    try {
                        const folders = fs.readdirSync(adobePath);
                        // หาโฟลเดอร์ที่มีคำว่า After Effects
                        const aeFolders = folders.filter(f => f.toLowerCase().includes('after effects'));
                        
                        // เรียงปีล่าสุดขึ้นก่อน
                        aeFolders.sort((a, b) => b.localeCompare(a));

                        for (let i = 0; i < aeFolders.length; i++) {
                            const checkPath = path.join(adobePath, aeFolders[i], "Support Files", "aerender.exe");
                            if (fs.existsSync(checkPath)) {
                                return `"${checkPath}"`; // เจอแล้ว ส่งที่อยู่กลับไปเลย!
                            }
                        }
                    } catch(e) { console.log(e); }
                }
            }
            return null; // ถ้าหาไม่เจอจริงๆ ในทุกไดรฟ์
        }

function processNextPreview(ffmpegPath) {
            if (previewQueue.length === 0 || stopRequested) {
                document.getElementById('progress-banner').style.display = 'none';
                isGenerating = false;
                renderGrid(); 
                if(typeof changeGridSize === "function") changeGridSize(document.getElementById('size-slider').value);
                return;
            }

            isGenerating = true;
            updateProgressUI();
            
            const task = previewQueue.shift(); 
            const isMogrt = task.type.endsWith('.mogrt');
            const isAudio = task.type.endsWith('.wav') || task.type.endsWith('.mp3');

            // 🌟 ท่าไม้ตายที่ 1: บังคับ Windows ให้อ่านชื่อไฟล์ "ภาษาไทย" ได้ 100% 🌟
            const runCmdSafely = (cmdStr, callback) => {
                exec(`chcp 65001 >nul & ${cmdStr}`, callback);
            };

            const runFfmpeg = (mediaPath, cleanupCallback) => {
                const isStaticImg = mediaPath.match(/\.(png|jpg|jpeg|webp|gif)$/i);
                if (isStaticImg) {
                    const cmd = `"${ffmpegPath}" -i "${mediaPath.replace(/\"/g, '\\"')}" -vf "scale=512:-2" -frames:v 1 -y "${task.output}"`;
                    runCmdSafely(cmd, (err) => {
                        if (cleanupCallback) cleanupCallback();
                        if (currentSelectedDir === task.dir) {
                            renderGrid();
                            if(typeof changeGridSize === "function") changeGridSize(document.getElementById('size-slider').value);
                        }
                        processNextPreview(ffmpegPath);
                    });
                } else {
                    runCmdSafely(`"${ffmpegPath}" -i "${mediaPath.replace(/\"/g, '\\"')}" 2>&1`, (err, stdout, stderr) => {
                        if (stopRequested) { if(cleanupCallback) cleanupCallback(); return; }
                        const match = (stderr || stdout).match(/Duration: (\d{2}):(\d{2}):(\d{2}\.\d{2})/);
                        let duration = 5; 
                        if (match) duration = parseFloat(match[1]) * 3600 + parseFloat(match[2]) * 60 + parseFloat(match[3]);
                        
                        // 🌟 เฉลี่ยดึงเฟรม 20 เฟรมตั้งแต่ต้นจนจบวิดีโอ 100% 🌟
                        let totalFrames = 20;
                        let fps = totalFrames / duration;
                        
                        // ปรับจาก tile=1x10 เป็น 1x20 (เรียงดิ่ง 20 เฟรม)
                        const cmd = `"${ffmpegPath}" -i "${mediaPath.replace(/\"/g, '\\"')}" -t ${duration} -vf "fps=${fps},scale=320:180:force_original_aspect_ratio=decrease,pad=320:180:(ow-iw)/2:(oh-ih)/2:color=0x00000000,tile=1x20" -frames:v 1 -y "${task.output}"`;
                        runCmdSafely(cmd, (err2) => {
                            if (cleanupCallback) cleanupCallback();
                            if (currentSelectedDir === task.dir) {
                                renderGrid();
                            }
                            processNextPreview(ffmpegPath);
                        });
                    });
                }
            };

            if (task.external) { runFfmpeg(task.external, null); return; }

            if (isAudio) {
                const cmd = `"${ffmpegPath}" -i "${task.input.replace(/\"/g, '\\"')}" -filter_complex "volume=5,showwavespic=s=320x180:split_channels=1:colors=white" -frames:v 1 -y "${task.output}"`;
                runCmdSafely(cmd, (err) => {
                    if (currentSelectedDir === task.dir) {
                        renderGrid();
                        if(typeof changeGridSize === "function") changeGridSize(document.getElementById('size-slider').value);
                    }
                    processNextPreview(ffmpegPath);
                });
                return;
            }

            if (isMogrt) {
                // 🌟 ท่าไม้ตายที่ 2: ย้ายไปแตกไฟล์ใน Temp ของ Windows เพื่อหนีปัญหาชื่อโฟลเดอร์ภาษาไทย 🌟
                const os = require('os');
                const tempDir = path.join(os.tmpdir(), 'bluebird_temp_' + Math.floor(Math.random() * 1000000));
                const tempZip = tempDir + '.zip';

                try {
                    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir);
                    fs.copyFileSync(task.input, tempZip);
                    
                    

                    exec(`powershell -Command "Expand-Archive -LiteralPath '${tempZip.replace(/'/g, "''")}' -DestinationPath '${tempDir.replace(/'/g, "''")}' -Force"`, (err, stdout, stderr) => {
                        try { if(fs.existsSync(tempZip)) fs.unlinkSync(tempZip); } catch(e){}
                        
                        let pFile = null;
                        if (fs.existsSync(tempDir)) {
                            function findMedia(dir) {
                                let results = [];
                                try {
                                    const list = fs.readdirSync(dir);
                                    list.forEach(f => {
                                        let fullPath = path.join(dir, f);
                                        const stat = fs.statSync(fullPath);
                                        if (stat && stat.isDirectory()) results = results.concat(findMedia(fullPath));
                                        else results.push(fullPath);
                                    });
                                } catch(e){}
                                return results;
                            }
                            const allFiles = findMedia(tempDir);
                            
                            pFile = allFiles.find(f => f.match(/\.(webm|mp4|mov|m4v|webp)$/i));
                            
                            // ถ้าไม่มีวีดีโอฝังมา เข้าสู่ระบบล่องหน
                            if (!pFile) {
                                const aeProject = allFiles.find(f => f.match(/\.(aep|aegraphic)$/i));
                                const defJson = allFiles.find(f => f.match(/definition\.json$/i));
                                
                                if (aeProject) {
                                    let compName = "";
                                    
                                    // 1. พยายามงัดชื่อจากไฟล์ระบบ (ครอบคลุมรูปแบบใหม่ๆ ของ Adobe)
                                    if (defJson) {
                                        try {
                                            const defData = JSON.parse(fs.readFileSync(defJson, 'utf8'));
                                            compName = defData.compositionName || defData.sourceCompositionName || (defData.composition && defData.composition.name) || "";
                                        } catch(e) {}
                                    }
                                    
                                    // 2. ถ้ายังหาไม่เจอ ให้ใช้ชื่อเดียวกับไฟล์ MOGRT ตัวนั้นเลย
                                    if (!compName && task.input) {
                                        compName = path.basename(task.input, path.extname(task.input));
                                    }

                                    const aeRenderPath = getAerenderPath();
                                    
                                    if (aeRenderPath) {
                                        const tempVideo = path.join(tempDir, 'hidden_render.avi');
                                        const extractDir = path.join(tempDir, 'extracted_mogrt');
                                        const cleanAePath = aeRenderPath.replace(/aerender\.exe/i, 'AfterFX.exe').replace(/"/g, '');
                                        const jsxPath = path.join(tempDir, 'agent_script.jsx');
                                        
                                        const safeVideo = tempVideo.replace(/\\/g, '/');
                                        const safeLog = path.join(tempDir, 'ae_inner_log.txt').replace(/\\/g, '/');
                                        
                                        if (!fs.existsSync(extractDir)) fs.mkdirSync(extractDir);
                                        
                                        const zipFile = path.join(tempDir, 'project_copy.zip');
                                        fs.copyFileSync(aeProject, zipFile);
                                        
                                        exec(`tar -xf "${zipFile}" -C "${extractDir}"`, (err, stdout, stderr) => {
                                            function findAepFile(dir) {
                                                if (!fs.existsSync(dir)) return null;
                                                let files = fs.readdirSync(dir);
                                                for (let i = 0; i < files.length; i++) {
                                                    let fullPath = path.join(dir, files[i]);
                                                    if (fs.statSync(fullPath).isDirectory()) {
                                                        let res = findAepFile(fullPath);
                                                        if (res) return res;
                                                    } else if (fullPath.toLowerCase().endsWith('.aep')) {
                                                        return fullPath;
                                                    }
                                                }
                                                return null;
                                            }
                                            
                                            let aepFile = findAepFile(extractDir);

                                            if (aepFile) {
                                                const safeAepPath = path.join(extractDir, 'extracted_safe.aep');
                                                fs.renameSync(aepFile, safeAepPath);
                                                const finalAepForJsx = safeAepPath.replace(/\\/g, '/');

                                                const jsxCode = `
                                                var logF = new File("${safeLog}");
                                                logF.open("w");
                                                logF.writeln("1. Script Started");
                                                try {
                                                    app.beginSuppressDialogs();
                                                    
                                                    // 🤫 1. นินจาทำงาน: แอบจำค่าเสียงดั้งเดิม แล้วสั่ง "ปิดเสียง"
                                                    var origSound = 1;
                                                    try {
                                                        if (app.preferences.havePref("Main Pref Section v2", "Play sound when render finishes")) {
                                                            origSound = app.preferences.getPrefAsLong("Main Pref Section v2", "Play sound when render finishes");
                                                        }
                                                        // สั่งปิดเสียง (0 = ปิด)
                                                        app.preferences.savePrefAsLong("Main Pref Section v2", "Play sound when render finishes", 0);
                                                    } catch(err) {}

                                                    var proj = new File("${finalAepForJsx}");
                                                    app.open(proj);
                                                    logF.writeln("2. AEP Opened");
                                                    
                                                    var targetComp = null;
                                                    for (var i = 1; i <= app.project.numItems; i++) {
                                                        if (app.project.item(i) instanceof CompItem) {
                                                            targetComp = app.project.item(i);
                                                            break; 
                                                        }
                                                    }
                                                    
                                                    if (targetComp) {
                                                        logF.writeln("3. Comp Found: " + targetComp.name);
                                                        var rqItem = app.project.renderQueue.items.add(targetComp);
                                                        var outMod = rqItem.outputModule(1);
                                                        outMod.file = new File("${safeVideo}");
                                                        
                                                        // สั่งเรนเดอร์ (คราวนี้จะเงียบกริบ ไม่มีเสียงร้องกวนใจ)
                                                        app.project.renderQueue.render();
                                                        logF.writeln("4. Render Completed");
                                                    } else {
                                                        logF.writeln("3. ERROR: No Comp found");
                                                    }
                                                } catch(e) {
                                                    logF.writeln("ERROR: " + e.toString());
                                                }
                                                
                                                // 🔊 2. นินจาถอนตัว: พอเรนเดอร์เสร็จ คืนค่าเสียงกลับเป็นเหมือนเดิมให้ลูกค้า
                                                try {
                                                    app.preferences.savePrefAsLong("Main Pref Section v2", "Play sound when render finishes", origSound);
                                                    app.preferences.saveToDisk();
                                                } catch(err) {}

                                                try { app.project.close(CloseOptions.DO_NOT_SAVE_CHANGES); } catch(e){}
                                                logF.close();
                                                app.quit();
                                                `;
                                                
                                                fs.writeFileSync(jsxPath, jsxCode, 'utf8');

                                                const args = ['-noui', '-r', jsxPath];
                                                const { execFile } = require('child_process');
                                                
                                                execFile(cleanAePath, args, (err2, stdout2, stderr2) => {
                                                    
                                                    // 🌟 ท่าไม้ตายสุดท้าย: สแกนหาไฟล์วิดีโอที่ AE แอบเปลี่ยนนามสกุล! 🌟
                                                    let finalVideoToEncode = tempVideo;
                                                    if (!fs.existsSync(finalVideoToEncode) || fs.statSync(finalVideoToEncode).size === 0) {
                                                        try {
                                                            const tempFiles = fs.readdirSync(tempDir);
                                                            // กวาดหาทุกนามสกุลวิดีโอที่เป็นไปได้
                                                            const actualRender = tempFiles.find(f => f.startsWith('hidden_render') && f.match(/\.(avi|mov|mp4|mxf|webm)$/i) && fs.statSync(path.join(tempDir, f)).size > 0);
                                                            if (actualRender) {
                                                                finalVideoToEncode = path.join(tempDir, actualRender);
                                                            }
                                                        } catch(e){}
                                                    }

                                                    // ถ้าเจอไฟล์วิดีโอแล้ว ส่งเข้ากระบวนการ FFmpeg แปลงเป็นพรีวิวทันที!
                                                    if (fs.existsSync(finalVideoToEncode) && fs.statSync(finalVideoToEncode).size > 0) {
                                                        runFfmpeg(finalVideoToEncode, () => { safeRemove(tempDir); });
                                                    } else {
                                                        // ถ้าพลาดจริงๆ จะลิสต์รายชื่อไฟล์ทั้งหมดในโฟลเดอร์ออกมาดูเลยว่า AE แอบสร้างเป็นไฟล์อะไร
                                                        let inner = "No log";
                                                        try { inner = fs.readFileSync(path.join(tempDir, 'ae_inner_log.txt'), 'utf8'); } catch(e){}
                                                        let tempDump = "";
                                                        try { tempDump = fs.readdirSync(tempDir).join(', '); } catch(e){}
                                                        try {
                                                            fs.writeFileSync(path.join(process.env.USERPROFILE, 'Desktop', 'afterfx_ultimate.txt'), "STDOUT:\n" + stdout2 + "\nSTDERR:\n" + stderr2 + "\nLOG:\n" + inner + "\nFILES IN TEMP:\n" + tempDump);
                                                        } catch(e){}

                                                        let fallbackImg = allFiles.find(f => f.match(/\.(png|jpg|jpeg)$/i));
                                                        if (fallbackImg) runFfmpeg(fallbackImg, () => { safeRemove(tempDir); });
                                                        else { safeRemove(tempDir); processNextPreview(ffmpegPath); }
                                                    }
                                                });
                                            } else {
                                                let fallbackImg = allFiles.find(f => f.match(/\.(png|jpg|jpeg)$/i));
                                                if (fallbackImg) runFfmpeg(fallbackImg, () => { safeRemove(tempDir); });
                                                else { safeRemove(tempDir); processNextPreview(ffmpegPath); }
                                            }
                                        });
                                        return; 
                                    }
                                }
                            }
                            
                            if(!pFile) pFile = allFiles.find(f => f.match(/\.(png|jpg|jpeg)$/i));
                        }
                        
                        if (!pFile && task.externalImg) pFile = task.externalImg;

                        if (pFile) { 
                            runFfmpeg(pFile, () => { safeRemove(tempDir); }); 
                        } else { 
                            safeRemove(tempDir); 
                            processNextPreview(ffmpegPath); 
                        }
                    });
                } catch(e) { processNextPreview(ffmpegPath); }
            } else { runFfmpeg(task.input, null); }
        }

function findMedia(dir) {
                                let results = [];
                                try {
                                    const list = fs.readdirSync(dir);
                                    list.forEach(f => {
                                        let fullPath = path.join(dir, f);
                                        const stat = fs.statSync(fullPath);
                                        if (stat && stat.isDirectory()) results = results.concat(findMedia(fullPath));
                                        else results.push(fullPath);
                                    });
                                } catch(e){}
                                return results;
                            }

function findAepFile(dir) {
                                                if (!fs.existsSync(dir)) return null;
                                                let files = fs.readdirSync(dir);
                                                for (let i = 0; i < files.length; i++) {
                                                    let fullPath = path.join(dir, files[i]);
                                                    if (fs.statSync(fullPath).isDirectory()) {
                                                        let res = findAepFile(fullPath);
                                                        if (res) return res;
                                                    } else if (fullPath.toLowerCase().endsWith('.aep')) {
                                                        return fullPath;
                                                    }
                                                }
                                                return null;
                                            }

function showInExplorer() {
            if(!contextTarget) return;
            exec(`explorer "${contextTarget}"`);
            document.getElementById('context-menu').style.display = 'none';
        }

function showInExplorer() {
            if(!contextTarget) return;
            try {
                if (fs.statSync(contextTarget).isFile()) {
                    exec(`explorer /select,"${contextTarget}"`);
                } else {
                    exec(`explorer "${contextTarget}"`);
                }
            } catch(e) {
                exec(`explorer "${contextTarget}"`);
            }
            document.getElementById('context-menu').style.display = 'none';
        }

function removeSelectedFolder() {
            if(!contextTarget) return;
            let savedFolders = [];
            try {
                savedFolders = JSON.parse(bluebirdStorage.getItem('bluebird_folders')) || [];
            } catch(e) {}
            if(savedFolders.includes(contextTarget)) {
                savedFolders = savedFolders.filter(f => f !== contextTarget);
                bluebirdStorage.setItem('bluebird_folders', JSON.stringify(savedFolders));
                document.getElementById('context-menu').style.display = 'none';
                currentSelectedDir = null;
                document.getElementById('asset-grid').innerHTML = '<p style="grid-column: 1 / -1; text-align: center; color: var(--text-light); margin-top: 40px;">โปรดเลือกโฟลเดอร์จากคลังสื่อ</p>';
                loadSavedFolders();
            }
        }

function removeSelectedFolder() {
            if(!contextTarget) return;
            let savedFolders = [];
            try { savedFolders = JSON.parse(bluebirdStorage.getItem('bluebird_folders')) || []; } catch(e) {}
            
            if (contextTargetType === 'sub-library') {
                let idx = savedFolders.findIndex(p => p.type === 'library' && p.id === contextTarget);
                if (idx > -1) {
                    if(savedFolders[idx].locked) { showCustomDialog('alert', "🔒 ไลบรารี่นี้ถูกล็อคอยู่ ไม่สามารถลบได้ครับ"); document.getElementById('context-menu').style.display = 'none'; return; }
                    showCustomDialog('confirm', "ต้องการลบไลบรารี่ '" + savedFolders[idx].name + "' และโฟลเดอร์ทั้งหมดข้างในหรือไม่?", "", (confirm) => {
                        if(confirm) {
                            let nextIdx = savedFolders.findIndex((p, i) => i > idx && p.type === 'library');
                            if (nextIdx === -1) nextIdx = savedFolders.length;
                            savedFolders.splice(idx, nextIdx - idx); 
                            bluebirdStorage.setItem('bluebird_folders', JSON.stringify(savedFolders)); loadSavedFolders();
                        }
                    });
                }
            } else {
                if(savedFolders.includes(contextTarget)) {
                    let targetIdx = savedFolders.indexOf(contextTarget); let destLocked = false;
                    for(let i=0; i<targetIdx; i++) { if(savedFolders[i] && savedFolders[i].type === 'library') destLocked = savedFolders[i].locked; }
                    if(destLocked) { showCustomDialog('alert', "🔒 โฟลเดอร์นี้อยู่ในไลบรารี่ที่ล็อคอยู่ ไม่สามารถลบได้ครับ"); document.getElementById('context-menu').style.display = 'none'; return; }
                    savedFolders = savedFolders.filter(f => f !== contextTarget);
                    bluebirdStorage.setItem('bluebird_folders', JSON.stringify(savedFolders)); currentSelectedDir = null;
                    document.getElementById('asset-grid').innerHTML = '<p style="grid-column: 1 / -1; text-align: center; color: var(--text-light); margin-top: 40px;">โปรดเลือกโฟลเดอร์จากคลังสื่อ</p>';
                    loadSavedFolders();
                }
            }
            document.getElementById('context-menu').style.display = 'none';
        }

function addNewLibrary(afterId) {
            let name = prompt("ตั้งชื่อไลบรารี่ใหม่:", "NEW LIBRARY");
            if (!name) return;

            let savedList = JSON.parse(bluebirdStorage.getItem('bluebird_folders')) || [];
            let newLib = { type: 'library', id: 'lib_' + Date.now(), name: name.toUpperCase(), locked: false };

            if (afterId) {
                // แทรกไลบรารี่ใหม่ไว้ใต้ตัวที่กด +
                let idx = savedList.findIndex(p => (p.type === 'library' ? p.id : p) === afterId);
                savedList.splice(idx + 1, 0, newLib);
            } else {
                savedList.push(newLib);
            }
            bluebirdStorage.setItem('bluebird_folders', JSON.stringify(savedList));
            loadSavedFolders();
        }

function addNewLibrary() {
            showCustomDialog('prompt', "ตั้งชื่อไลบรารี่ใหม่:", "NEW LIBRARY", (name) => {
                if (!name) return;
                let savedList = JSON.parse(bluebirdStorage.getItem('bluebird_folders')) || [];
                savedList.push({ type: 'library', id: 'lib_' + Date.now(), name: name.toUpperCase(), locked: false }); 
                bluebirdStorage.setItem('bluebird_folders', JSON.stringify(savedList)); loadSavedFolders();
            });
        }

function toggleLibLock(libId) {
            let savedList = JSON.parse(bluebirdStorage.getItem('bluebird_folders')) || [];
            let lib = savedList.find(p => p.type === 'library' && p.id === libId);
            if (lib) {
                lib.locked = !lib.locked;
                bluebirdStorage.setItem('bluebird_folders', JSON.stringify(savedList));
                loadSavedFolders();
            }
        }

function toggleLibLock(libId) {
            let savedList = JSON.parse(bluebirdStorage.getItem('bluebird_folders')) || [];
            let lib = savedList.find(p => p.type === 'library' && p.id === libId);
            if (lib) { lib.locked = !lib.locked; bluebirdStorage.setItem('bluebird_folders', JSON.stringify(savedList)); loadSavedFolders(); }
        }

function renameLibrary(libId) {
            let savedList = JSON.parse(bluebirdStorage.getItem('bluebird_folders')) || [];
            let lib = savedList.find(p => p.type === 'library' && p.id === libId);
            if (lib) {
                if (lib.locked) {
                    alert("🔒 กรุณาปลดล็อคไลบรารี่ก่อนเปลี่ยนชื่อครับ");
                    return;
                }
                let name = prompt("เปลี่ยนชื่อไลบรารี่:", lib.name);
                if (name) {
                    lib.name = name.toUpperCase();
                    bluebirdStorage.setItem('bluebird_folders', JSON.stringify(savedList));
                    loadSavedFolders();
                }
            }
        }

function renameLibrary(libId) {
            let savedList = JSON.parse(bluebirdStorage.getItem('bluebird_folders')) || [];
            let lib = savedList.find(p => p.type === 'library' && p.id === libId);
            if (lib) {
                if (lib.locked) { showCustomDialog('alert', "🔒 กรุณาปลดล็อคไลบรารี่ก่อนเปลี่ยนชื่อครับ"); return; }
                showCustomDialog('prompt', "เปลี่ยนชื่อไลบรารี่:", lib.name, (name) => {
                    if (name) { lib.name = name.toUpperCase(); bluebirdStorage.setItem('bluebird_folders', JSON.stringify(savedList)); loadSavedFolders(); }
                });
            }
        }

function moveLibraryChunk(libId, dir) {
            let list = JSON.parse(bluebirdStorage.getItem('bluebird_folders')) || [];
            let idx = list.findIndex(p => p.type === 'library' && p.id === libId);
            if(idx < 0) return;
            let nextIdx = list.findIndex((p, i) => i > idx && p.type === 'library');
            if(nextIdx === -1) nextIdx = list.length;
            let chunk = list.slice(idx, nextIdx);

            if(dir === 'up') {
                let prevIdx = -1;
                for(let i = idx - 1; i >= 0; i--) { if(list[i] && list[i].type === 'library') { prevIdx = i; break; } }
                if(prevIdx === -1 || list[prevIdx].id === 'lib_init') return; 
                list.splice(idx, chunk.length); list.splice(prevIdx, 0, ...chunk);
            } else if(dir === 'down') {
                if(nextIdx === list.length) return; 
                let nextNextIdx = list.findIndex((p, i) => i > nextIdx && p.type === 'library');
                if(nextNextIdx === -1) nextNextIdx = list.length;
                let nextChunkLen = nextNextIdx - nextIdx;
                list.splice(idx, chunk.length); list.splice(idx + nextChunkLen, 0, ...chunk); 
            }
            bluebirdStorage.setItem('bluebird_folders', JSON.stringify(list)); loadSavedFolders();
        }

function quickScan(dir) {
                if(hasMogrt) return;
                try {
                    const items = fs.readdirSync(dir, { withFileTypes: true });
                    for(let i = 0; i < items.length; i++) {
                        let item = items[i];
                        if(item.isDirectory() && item.name !== '_Blue Bird Previews') {
                            quickScan(path.join(dir, item.name));
                        } else if(!item.isDirectory()) {
                            if(item.name.toLowerCase().endsWith('.mogrt')) {
                                hasMogrt = true; return;
                            }
                        }
                    }
                } catch(e) {}
            }


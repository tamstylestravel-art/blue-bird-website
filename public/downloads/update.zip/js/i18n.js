(function() {
    const fs = require('fs');
    const path = require('path');

    // พจนานุกรมแปลภาษา (คุณสามารถเพิ่มภาษาที่นี่ได้ในอนาคต เช่น es, ja)
    const locales = {
        en: {
            "auth_loading_account": "Loading account data...",
            "auth_subtitle": "Please log in to continue",
            "auth_email": "Email",
            "auth_password": "Password",
            "auth_login_btn": "Login",
            "auth_logging_in_btn": "Logging in...",
            "auth_err_empty": "Please enter both email and password.",
            "auth_err_email_format": "Invalid email format.",
            "auth_err_wrong_pwd": "Incorrect email or password.",
            "auth_err_too_many": "Too many failed attempts. Please try again later.",
            "auth_err_general": "Login failed. Please try again.",
            "auth_no_account": "Don't have an account?",
            "auth_signup_btn": "Sign Up",
            "auth_forgot_pwd": "Forgot Password?",
            "auth_reset_sent": "Password reset link sent to your email.",
            "auth_or": "or",
            "auth_google_login": "Login with Browser",
            "error_title": "⚠️ Critical Error",
            "error_subtitle": "The plugin encountered a critical issue. Please copy the information below and send it to the developer.",
            "error_copy": "📋 Copy Log",
            "error_copied": "✅ Copied!",
            "error_copy_fail": "❌ Copy Failed",
            "settings_title": "⚙️ Settings",
            "settings_general": "🌐 General",
            "settings_account": "👤 Account",
            "settings_advanced": "🛠️ Advanced",
            "settings_language": "Language",
            "settings_placeholder_account": "Account settings coming soon...",
            "settings_placeholder_advanced": "Advanced settings coming soon...",
            "magic_clear_cache": "Clear AE Cache",
            "magic_clear_cache_title": "🧹 Clear Cache",
            "main_btn_magic_tools": "Blue Bird Magic Tools",
            "magic_auto_cut": "Auto Cut<br>Dead Air",
            "magic_auto_beat_sync": "Auto Beat<br>Sync",
            "magic_auto_ducking": "Auto<br>Ducking",
            "magic_loudness_match": "Loudness<br>Match",
            "magic_beat_sync": "Beat<br>Sync",
            "magic_voice_enhance": "Voice<br>Enhance",
            "magic_noise_removal": "Noise<br>Removal",
            "magic_auto_color": "Auto<br>Color",
            "magic_auto_subtitle": "Auto<br>Subtitle",
            "magic_project_cleaner": "Project<br>Cleaner",
            "magic_smart_render": "Smart<br>Render",
            "autocut_title": "Auto Cut Dead Air",
            "autocut_warning_title": "Warning (Important)",
            "autocut_warning_desc_1": "All video effects will be removed (except Scale).",
            "autocut_warning_desc_2": "Recommendation",
            "autocut_warning_desc_3": "Please complete Auto Cut Dead Air<br>before color grading or adding other effects.",
            "autocut_scan_tooltip": "💡 Tip: Please select a video track first.",
            "autocut_scan_btn": "Scan & Analyze Audio",
            "autocut_threshold": "Silence Threshold (dB)",
            "autocut_duration": "Min Duration (sec)",
            "autocut_padding": "Audio Padding (sec)",
            "autocut_ripple": "Ripple Delete (Remove gaps between clips)",
            "autocut_live_preview": "Live Preview",
            "autocut_zoom": "Zoom",
            "autocut_start_btn": "✂️ Start Cut",
            "license_title": "BLUE BIRD PRO - License Agreement",
            "license_h4": "Terms of Use",
            "license_p1": "Welcome to <b>Blue Bird Composer (PRO V." + window.GLOBAL_APP_VERSION + ")</b>, the studio-level software and resource library. The use of this software and all digital assets is subject to the following conditions:",
            "license_h_comm": "1. Commercial Use",
            "license_p_comm": "You are free to use all audio, sound effects, graphics, and templates in any creative works such as commercials, documentaries, YouTube videos, TV shows, and all social media platforms globally without additional royalty fees (Royalty-Free).",
            "license_h_rest": "2. Restrictions",
            "license_p_rest": "You are strictly prohibited from reproducing, distributing, uploading for free download, modifying to resell, or claiming copyright on the raw audio files or templates in any asset library or template package format.",
            "license_h_supp": "3. Support & Updates",
            "license_p_supp": "PRO users will receive constant stability updates for the application features and will get lifetime free access to new audio/template packages to be updated in the future.",
            "license_h_liab": "4. Liability",
            "license_p_liab": "The Blue Bird Pictures Studio development team is not responsible for any damages resulting from the use of the files or loss of project data. Users should regularly back up their data.",
            "license_h_term": "5. Termination",
            "license_p_term": "If a user is found violating the agreement, especially by distributing or reselling, the studio reserves the right to terminate the License and immediately suspend access to the update system without prior notice.",
            "license_end": "-- End of Terms of Use --<br><br><b>Blue Bird Pictures Studio © 2026</b>"
        },
        th: {
            "auth_loading_account": "กำลังโหลดข้อมูลบัญชี...",
            "auth_subtitle": "กรุณาเข้าสู่ระบบเพื่อดำเนินการต่อ",
            "auth_email": "อีเมล",
            "auth_password": "รหัสผ่าน",
            "auth_login_btn": "เข้าสู่ระบบ",
            "auth_logging_in_btn": "กำลังเข้าสู่ระบบ...",
            "auth_err_empty": "กรุณากรอกอีเมลและรหัสผ่านให้ครบถ้วน",
            "auth_err_email_format": "รูปแบบอีเมลไม่ถูกต้อง",
            "auth_err_wrong_pwd": "อีเมลหรือรหัสผ่านไม่ถูกต้อง",
            "auth_err_too_many": "พยายามเข้าสู่ระบบล้มเหลวหลายครั้งเกินไป กรุณารอสักครู่แล้วลองใหม่",
            "auth_err_general": "เกิดข้อผิดพลาดในการเข้าสู่ระบบ กรุณาลองใหม่อีกครั้ง",
            "auth_no_account": "ยังไม่มีบัญชีผู้ใช้งาน?",
            "auth_signup_btn": "สมัครสมาชิก",
            "auth_forgot_pwd": "ลืมรหัสผ่าน?",
            "auth_reset_sent": "ส่งลิงก์รีเซ็ตรหัสผ่านไปที่อีเมลของคุณแล้ว",
            "auth_or": "หรือ",
            "auth_google_login": "เข้าสู่ระบบด้วยเบราว์เซอร์",
            "error_title": "⚠️ เกิดข้อผิดพลาดร้ายแรง (Critical Error)",
            "error_subtitle": "ปลั๊กอินพบปัญหาที่ไม่สามารถทำงานต่อได้ โปรดคัดลอกข้อมูลด้านล่างแล้วส่งให้ทีมพัฒนา",
            "error_copy": "📋 คัดลอกข้อมูลแจ้งปัญหา (Copy Log)",
            "error_copied": "✅ คัดลอกเรียบร้อยแล้ว!",
            "error_copy_fail": "❌ คัดลอกไม่สำเร็จ",
            "settings_title": "⚙️ Settings (การตั้งค่า)",
            "settings_general": "🌐 ทั่วไป",
            "settings_about": "ℹ️ เกี่ยวกับ (About)",
            "settings_advanced": "🛠️ ขั้นสูง",
            "settings_language": "ภาษา (Language)",
            "settings_placeholder_about": "Blue Bird Composer V." + window.GLOBAL_APP_VERSION,
            "settings_placeholder_advanced": "การตั้งค่าขั้นสูงจะเปิดให้ใช้งานเร็วๆ นี้...",
            "magic_clear_cache": "Clear AE Cache",
            "magic_clear_cache_title": "🧹 Clear After Effects Cache",
            "main_btn_magic_tools": "เครื่องมือวิเศษ (Magic Tools)",
            "magic_auto_cut": "ตัดคำเงียบ<br>อัตโนมัติ",
            "magic_auto_beat_sync": "ตัดต่อตามจังหวะ<br>อัตโนมัติ",
            "magic_auto_ducking": "หรี่เสียงเพลง<br>อัตโนมัติ",
            "magic_loudness_match": "ปรับระดับเสียง<br>มาตรฐาน",
            "magic_beat_sync": "มาร์คจังหวะ<br>อัตโนมัติ",
            "magic_voice_enhance": "ปรับเสียงพูด<br>ให้ชัดเจน",
            "magic_noise_removal": "ตัดเสียงรบกวน<br>อัตโนมัติ",
            "magic_auto_color": "แต่งสี<br>อัตโนมัติ",
            "magic_auto_subtitle": "สร้างซับไตเติ้ล<br>อัตโนมัติ",
            "magic_project_cleaner": "จัดระเบียบ<br>โปรเจกต์",
            "magic_smart_render": "เรนเดอร์<br>อัจฉริยะ",
            "autocut_title": "ตัดคำเงียบอัตโนมัติ (Auto Cut Dead Air)",
            "autocut_warning_title": "ข้อควรระวัง (โปรดอ่านสำคัญมาก)",
            "autocut_warning_desc_1": "เอฟเฟกต์วิดีโอจะถูกล้างค่าทั้งหมด (ยกเว้น Scale)",
            "autocut_warning_desc_2": "คำแนะนำ",
            "autocut_warning_desc_3": "ให้ทำ Auto Cut Dead Air ให้เสร็จสมบูรณ์<br>ก่อนนำคลิปไปปรับแต่งสีหรือใส่เอฟเฟกต์เพิ่มเติม",
            "autocut_scan_tooltip": "💡 แนะนำ: กรุณาเลือกแทร็กวิดีโอก่อน",
            "autocut_scan_btn": "สแกนและวิเคราะห์เสียง",
            "autocut_threshold": "ระดับเสียงเงียบ (Threshold dB)",
            "autocut_duration": "ระยะเวลาขั้นต่ำ (Min sec)",
            "autocut_padding": "เผื่อความยาวเสียง (Padding sec)",
            "autocut_ripple": "Ripple Delete (ลบช่องว่างให้คลิปชนกันสนิท)",
            "autocut_live_preview": "ดูตัวอย่างสด (Live Preview)",
            "autocut_zoom": "ซูม (Zoom)",
            "autocut_start_btn": "✂️ ตัดคลิปทันที (Start Cut)",
            "license_title": "BLUE BIRD PRO - License Agreement",
            "license_h4": "ข้อตกลงและเงื่อนไขการใช้งาน (Terms of Use)",
            "license_p1": "ยินดีต้อนรับสู่ <b>Blue Bird Composer (PRO V." + window.GLOBAL_APP_VERSION + ")</b> ซอฟต์แวร์และคลังทรัพยากรระดับสตูดิโอโปรดักชัน การใช้งานซอฟต์แวร์และสินทรัพย์ดิจิทัลทั้งหมดอยู่ภายใต้เงื่อนไขดังต่อไปนี้:",
            "license_h_comm": "1. สิทธิ์การใช้งานเชิงพาณิชย์ (Commercial Use)",
            "license_p_comm": "อนุญาตให้นำเสียง ซาวด์เอฟเฟกต์ กราฟิก และเทมเพลตทั้งหมด ไปใช้ประกอบสร้างสรรค์ผลงานได้อย่างอิสระ เช่น ภาพยนตร์โฆษณา, ภาพยนตร์สารคดี, วิดีโอ YouTube, รายการโทรทัศน์ และสื่อโซเชียลมีเดียทุกแพลตฟอร์ม โดยไม่มีการเรียกเก็บค่าลิขสิทธิ์เพิ่มเติม (Royalty-Free) ทั่วโลก",
            "license_h_rest": "2. ข้อห้ามในการใช้งาน (Restrictions)",
            "license_p_rest": "ไม่อนุญาตให้นำไฟล์เสียงหรือเทมเพลตต้นฉบับ (Raw Assets) ไปทำซ้ำ, แจกจ่าย, อัปโหลดเพื่อให้ดาวน์โหลดฟรี, ดัดแปลงเพื่อนำไปขายต่อ (Resell) หรือนำไปจดลิขสิทธิ์ซ้ำ (Copyright Claim) ในรูปแบบของคลังเสียงหรือเทมเพลตแพ็กเกจโดยเด็ดขาด",
            "license_h_supp": "3. การสนับสนุนและการอัปเดต (Support & Updates)",
            "license_p_supp": "ผู้ใช้งานระดับ PRO จะได้รับการอัปเดตฟีเจอร์ของแอปพลิเคชันให้เสถียรอยู่เสมอ และได้รับสิทธิ์เข้าถึงแพ็กเกจเสียง/เทมเพลตชุดใหม่ๆ ที่จะอัปเดตในอนาคตฟรีตลอดอายุการใช้งาน",
            "license_h_liab": "4. ความรับผิดชอบ (Liability)",
            "license_p_liab": "ทีมผู้พัฒนา Blue Bird Pictures Studio จะไม่รับผิดชอบต่อความเสียหายใดๆ ที่เกิดขึ้นจากการใช้งานไฟล์ หรือการสูญหายของข้อมูลโปรเจกต์ ผู้ใช้ควรสำรองข้อมูล (Backup) อย่างสม่ำเสมอ",
            "license_h_term": "5. การยกเลิกสิทธิ์ (Termination)",
            "license_p_term": "หากพบว่าผู้ใช้งานมีการละเมิดข้อตกลง โดยเฉพาะการนำไปแจกจ่ายหรือขายต่อ ทางสตูดิโอขอสงวนสิทธิ์ในการยกเลิก License และระงับการเข้าถึงระบบอัปเดตทันที โดยไม่ต้องแจ้งให้ทราบล่วงหน้า",
            "license_end": "-- สิ้นสุดข้อตกลงการใช้งาน --<br><br><b>Blue Bird Pictures Studio © 2026</b>"
        },
        ja: {
            "error_title": "⚠️ 致命的なエラー (Critical Error)",
            "error_subtitle": "プラグインで重大な問題が発生しました。以下の情報をコピーして開発チームに送信してください。",
            "error_copy": "📋 ログをコピー (Copy Log)",
            "error_copied": "✅ コピーしました！",
            "error_copy_fail": "❌ コピー失敗",
            "settings_title": "⚙️ 設定 (Settings)",
            "settings_general": "🌐 一般",
            "settings_account": "👤 アカウント",
            "settings_advanced": "🛠️ 詳細設定",
            "settings_language": "言語 (Language)",
            "settings_placeholder_account": "アカウント設定は近日公開予定です...",
            "settings_placeholder_advanced": "詳細設定は近日公開予定です...",
            "magic_clear_cache": "キャッシュをクリア",
            "magic_clear_cache_title": "🧹 キャッシュをクリア",
            "main_btn_magic_tools": "魔法のツール (Magic Tools)",
            "magic_auto_cut": "無音カット<br>自動",
            "magic_auto_beat_sync": "ビート同期<br>自動",
            "magic_auto_ducking": "ダッキング<br>自動",
            "magic_loudness_match": "ラウドネス<br>均一化",
            "magic_beat_sync": "ビート同期",
            "magic_voice_enhance": "音声強調",
            "magic_noise_removal": "ノイズ除去",
            "magic_auto_color": "カラー補正<br>自動",
            "magic_auto_subtitle": "字幕作成<br>自動",
            "magic_project_cleaner": "プロジェクト<br>クリーン",
            "magic_smart_render": "スマート<br>レンダリング",
            "autocut_title": "無音カット (Auto Cut Dead Air)",
            "autocut_warning_title": "警告 (重要なお知らせ)",
            "autocut_warning_desc_1": "すべてのビデオエフェクトが削除されます（スケールを除く）。",
            "autocut_warning_desc_2": "推奨",
            "autocut_warning_desc_3": "カラーグレーディングやエフェクトを追加する前に、<br>無音カットを完了させてください。",
            "autocut_scan_tooltip": "💡 ヒント：まずビデオトラックを選択してください。",
            "autocut_scan_btn": "音声をスキャンして解析",
            "autocut_threshold": "無音しきい値 (Threshold dB)",
            "autocut_duration": "最小期間 (Min sec)",
            "autocut_padding": "音声パディング (Padding sec)",
            "autocut_ripple": "リップル削除 (クリップ間の隙間を削除)",
            "autocut_live_preview": "ライブプレビュー (Live Preview)",
            "autocut_zoom": "ズーム (Zoom)",
            "autocut_start_btn": "✂️ カット開始 (Start Cut)",
            "license_title": "BLUE BIRD PRO - ライセンス契約",
            "license_h4": "利用規約 (Terms of Use)",
            "license_p1": "<b>Blue Bird Composer (PRO V." + window.GLOBAL_APP_VERSION + ")</b>、スタジオレベルのソフトウェアおよびリソースライブラリへようこそ。このソフトウェアとすべてのデジタル資産の使用は、以下の条件に従います：",
            "license_h_comm": "1. 商業利用 (Commercial Use)",
            "license_p_comm": "すべての音声、サウンドエフェクト、グラフィック、およびテンプレートを、CM、ドキュメンタリー、YouTube動画、テレビ番組、および世界中のすべてのソーシャルメディアプラットフォームなど、あらゆる創造的な作品で、追加のロイヤリティ料金なしで（ロイヤリティフリー）自由に使用できます。",
            "license_h_rest": "2. 禁止事項 (Restrictions)",
            "license_p_rest": "生の音声ファイルやテンプレートを複製、配布、無料ダウンロード用にアップロードしたり、再販のために変更したり、アセットライブラリやテンプレートパッケージの形式で著作権を主張したりすることは固く禁じられています。",
            "license_h_supp": "3. サポートとアップデート (Support & Updates)",
            "license_p_supp": "PROユーザーは、アプリケーション機能の継続的な安定性アップデートを受け取り、将来アップデートされる新しい音声/テンプレートパッケージに生涯無料でアクセスできます。",
            "license_h_liab": "4. 責任 (Liability)",
            "license_p_liab": "Blue Bird Pictures Studio 開発チームは、ファイルの使用による損害やプロジェクトデータの喪失について責任を負いません。ユーザーは定期的にデータをバックアップする必要があります。",
            "license_h_term": "5. 契約解除 (Termination)",
            "license_p_term": "ユーザーが合意に違反していることが判明した場合、特に配布や再販によって、スタジオはライセンスを終了し、事前の通知なしにアップデートシステムへのアクセスを即座に停止する権利を留保します。",
            "license_end": "-- 利用規約の終わり --<br><br><b>Blue Bird Pictures Studio © 2026</b>"
        },
        ko: {
            "error_title": "⚠️ 치명적인 오류 (Critical Error)",
            "error_subtitle": "플러그인에 심각한 문제가 발생했습니다. 다음 정보를 복사하여 개발팀에 보내주세요.",
            "error_copy": "📋 로그 복사 (Copy Log)",
            "error_copied": "✅ 복사되었습니다!",
            "error_copy_fail": "❌ 복사 실패",
            "settings_title": "⚙️ 설정 (Settings)",
            "settings_general": "🌐 일반",
            "settings_account": "👤 계정",
            "settings_advanced": "🛠️ 고급 설정",
            "settings_language": "언어 (Language)",
            "settings_placeholder_account": "계정 설정은 곧 제공될 예정입니다...",
            "settings_placeholder_advanced": "고급 설정은 곧 제공될 예정입니다...",
            "magic_clear_cache": "캐시 지우기",
            "magic_clear_cache_title": "🧹 캐시 지우기",
            "main_btn_magic_tools": "매직 툴 (Magic Tools)",
            "magic_auto_cut": "자동 공백 자르기",
            "magic_auto_beat_sync": "자동 비트 동기화",
            "magic_auto_ducking": "자동 더킹",
            "magic_loudness_match": "음량 일치",
            "magic_beat_sync": "비트 동기화",
            "magic_voice_enhance": "음성 강조",
            "magic_noise_removal": "노이즈 제거",
            "magic_auto_color": "자동 색상 보정",
            "magic_auto_subtitle": "자동 자막",
            "magic_project_cleaner": "프로젝트 정리",
            "magic_smart_render": "스마트 렌더링",
            "autocut_title": "자동 공백 자르기 (Auto Cut Dead Air)",
            "autocut_warning_title": "경고 (중요 사항)",
            "autocut_warning_desc_1": "모든 비디오 효과가 제거됩니다(크기 조절 제외).",
            "autocut_warning_desc_2": "권장",
            "autocut_warning_desc_3": "색상 보정이나 효과를 추가하기 전에<br>자동 공백 자르기를 완료하세요.",
            "autocut_scan_tooltip": "💡 팁: 비디오 트랙을 먼저 선택하세요.",
            "autocut_scan_btn": "오디오 스캔 및 분석",
            "autocut_threshold": "무음 임계값 (Threshold dB)",
            "autocut_duration": "최소 기간 (Min sec)",
            "autocut_padding": "오디오 패딩 (Padding sec)",
            "autocut_ripple": "잔물결 삭제 (클립 간격 제거)",
            "autocut_live_preview": "라이브 미리보기 (Live Preview)",
            "autocut_zoom": "줌 (Zoom)",
            "autocut_start_btn": "✂️ 자르기 시작 (Start Cut)",
            "license_title": "BLUE BIRD PRO - 라이센스 계약",
            "license_h4": "이용 약관 (Terms of Use)",
            "license_p1": "스튜디오 수준의 소프트웨어 및 리소스 라이브러리인 <b>Blue Bird Composer (PRO V." + window.GLOBAL_APP_VERSION + ")</b>에 오신 것을 환영합니다. 이 소프트웨어와 모든 디지털 자산의 사용은 다음 조건에 따릅니다:",
            "license_h_comm": "1. 상업적 사용 (Commercial Use)",
            "license_p_comm": "모든 오디오, 사운드 이펙트, 그래픽 및 템플릿을 광고, 다큐멘터리, YouTube 비디오, TV 프로그램 및 전 세계 모든 소셜 미디어 플랫폼과 같은 창의적인 작업에서 추가 로열티 비용 없이(로열티 프리) 자유롭게 사용할 수 있습니다.",
            "license_h_rest": "2. 제한 사항 (Restrictions)",
            "license_p_rest": "원본 오디오 파일이나 템플릿을 복제, 배포, 무료 다운로드를 위해 업로드하거나, 재판매를 위해 수정하거나, 자산 라이브러리 또는 템플릿 패키지 형식으로 저작권을 주장하는 것은 엄격히 금지됩니다.",
            "license_h_supp": "3. 지원 및 업데이트 (Support & Updates)",
            "license_p_supp": "PRO 사용자는 애플리케이션 기능에 대한 지속적인 안정성 업데이트를 받으며 향후 업데이트될 새로운 오디오/템플릿 패키지에 평생 무료로 액세스할 수 있습니다.",
            "license_h_liab": "4. 책임 (Liability)",
            "license_p_liab": "Blue Bird Pictures Studio 개발팀은 파일 사용으로 인한 손해나 프로젝트 데이터 손실에 대해 책임을 지지 않습니다. 사용자는 정기적으로 데이터를 백업해야 합니다.",
            "license_h_term": "5. 계약 해지 (Termination)",
            "license_p_term": "사용자가 합의를 위반하는 것으로 확인될 경우, 특히 배포 또는 재판매에 의해, 스튜디오는 사전 통지 없이 라이센스를 종료하고 업데이트 시스템에 대한 액세스를 즉시 중단할 권리를 보유합니다.",
            "license_end": "-- 이용 약관 끝 --<br><br><b>Blue Bird Pictures Studio © 2026</b>"
        }
    };

    let currentLang = 'en'; // ค่าเริ่มต้นเป็นอังกฤษ

    try {
        const csInterface = new CSInterface();
        const userDataFolder = csInterface.getSystemPath(SystemPath.USER_DATA);
        const dataFile = path.join(userDataFolder, "Blue Bird Composer", "settings.json");
        
        if (fs.existsSync(dataFile)) {
            const data = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
            if (data.bluebird_language && locales[data.bluebird_language]) {
                currentLang = data.bluebird_language;
            }
        }
    } catch (e) {
        // หากมีปัญหาในการอ่านไฟล์เซฟ ให้ใช้ภาษาตั้งต้น (en) ต่อไป
    }

    window.i18n = {
        lang: currentLang,
        locales: locales,
        t: function(key) {
            return (this.locales[this.lang] && this.locales[this.lang][key]) ? this.locales[this.lang][key] : key;
        },
        setLanguage: function(langCode) {
            if (this.locales[langCode]) {
                this.lang = langCode;
                // เซฟค่าลงไฟล์
                if (window.bluebirdStorage) {
                    window.bluebirdStorage.setItem('bluebird_language', langCode);
                }
                // สั่งแปลภาษาทั้งแอปพลิเคชัน
                this.translateUI();
            }
        },
        translateUI: function() {
            const elements = document.querySelectorAll('[data-i18n]');
            elements.forEach(el => {
                const key = el.getAttribute('data-i18n');
                if (this.locales[this.lang] && this.locales[this.lang][key]) {
                    // รองรับ Input Placeholder
                    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
                        el.placeholder = this.locales[this.lang][key];
                    } else {
                        el.innerHTML = this.locales[this.lang][key];
                    }
                }
            });
            
            // Sync dropdown visual state
            const authLangSelector = document.getElementById('auth-lang-selector');
            if (authLangSelector && authLangSelector.value !== this.lang) {
                authLangSelector.value = this.lang;
            }
        }
    };
})();

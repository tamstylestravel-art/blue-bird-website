(function() {
    const fs = require('fs');
    const path = require('path');

    class StorageManager {
        constructor() {
            this.csInterface = new CSInterface();
            this.userDataFolder = this.csInterface.getSystemPath(SystemPath.USER_DATA);
            this.extensionFolder = path.join(this.userDataFolder, "Blue Bird Composer");
            this.dataFile = path.join(this.extensionFolder, "settings.json");
            this.data = {};
            this.init();
        }
        
        init() {
            if (!fs.existsSync(this.extensionFolder)) {
                fs.mkdirSync(this.extensionFolder, { recursive: true });
            }
            
            let needsSave = false;
            
            if (fs.existsSync(this.dataFile)) {
                try {
                    this.data = JSON.parse(fs.readFileSync(this.dataFile, 'utf8'));
                } catch (e) {
                    console.error("Error reading settings.json", e);
                    this.data = {};
                }
            }
            
            // Migrate existing data from localStorage to the JSON file
            const keysToMigrate = [
                'bluebird_folders', 'bluebird_favorites', 'bluebird_folder_colors',
                'bluebird_aerender_path', 'bluebird_album_subs', 'bluebird_collapsed_libs',
                'bluebird_auto_preview'
            ];
            
            keysToMigrate.forEach(key => {
                const val = localStorage.getItem(key);
                if (val !== null && val !== undefined) {
                    // Only migrate if we don't already have it in settings.json
                    if (this.data[key] === undefined) {
                        try {
                            this.data[key] = JSON.parse(val);
                        } catch (e) {
                            this.data[key] = val; 
                        }
                        needsSave = true;
                    }
                }
            });
            
            if (needsSave) {
                this.save();
            }
        }
        
        getItem(key) {
            if (this.data[key] !== undefined) {
                // Return as string to mimic localStorage behavior
                if (typeof this.data[key] === 'object') {
                    return JSON.stringify(this.data[key]);
                }
                return String(this.data[key]);
            }
            return null;
        }
        
        setItem(key, value) {
            try {
                // Try to parse to keep the JSON file clean and readable
                this.data[key] = JSON.parse(value);
            } catch (e) {
                this.data[key] = value;
            }
            this.save();
        }
        
        removeItem(key) {
            delete this.data[key];
            this.save();
        }
        
        save() {
            try {
                fs.writeFileSync(this.dataFile, JSON.stringify(this.data, null, 2), 'utf8');
            } catch (e) {
                console.error("Error writing settings.json", e);
            }
        }
    }

    // Instantiate and expose globally
    window.bluebirdStorage = new StorageManager();
})();

// --- audio-player.js ---

function getAudioContext() {
            try {
                if (!audioCtx) {
                    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
                    if (AudioContextClass) {
                        audioCtx = new AudioContextClass();
                    }
                }
            } catch(e) { console.error(e); }
            return audioCtx;
        }

function updateSliderFill(slider, color = '#3b82f6') {
            if(!slider) return;
            const min = parseFloat(slider.min) || 0;
            const max = parseFloat(slider.max) || 1;
            const val = parseFloat(slider.value);
            const percentage = ((val - min) / (max - min)) * 100;
            slider.style.background = `linear-gradient(to right, ${color} ${percentage}%, var(--border-light) ${percentage}%)`;
        }

function loadAndDrawWaveform(filePath) {
            const canvas = document.getElementById('waveform-canvas');
            if(!canvas) return;
            
            const waveArea = document.getElementById('audio-waveform-area');
            if (waveArea) {
                waveArea.style.opacity = '0'; 
                waveArea.style.animation = 'none'; 
            }

            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height); 
            originalAudioBuffer = null;

            try {
                const actx = getAudioContext();
                if (!actx) return;

                const buffer = fs.readFileSync(filePath);
                const arrayBuffer = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);

                actx.decodeAudioData(arrayBuffer, function(decodedAudio) {
                    originalAudioBuffer = decodedAudio;
                    drawWaveform(); 
                }, function(e) {
                    console.error("Error decoding audio data", e);
                });
                
            } catch (err) {
                console.error("Error drawing waveform:", err);
            }
        }

function drawWaveform() {
            if (!originalAudioBuffer) return;
            const canvas = document.getElementById('waveform-canvas');
            const dpr = window.devicePixelRatio || 1;
            
            const rect = canvas.parentElement.getBoundingClientRect();
            if(rect.width === 0) return; 
            
            canvas.width = rect.width * dpr;
            canvas.height = rect.height * dpr;
            const ctx = canvas.getContext('2d');
            ctx.scale(dpr, dpr);

            const width = rect.width;
            const height = rect.height;

            ctx.clearRect(0, 0, width, height);
            ctx.fillStyle = '#ffffff'; 

            const channels = originalAudioBuffer.numberOfChannels;
            
            drawChannel(ctx, originalAudioBuffer.getChannelData(0), width, height / 2, 0);
            drawChannel(ctx, originalAudioBuffer.getChannelData(channels > 1 ? 1 : 0), width, height / 2, height / 2);

            const waveArea = document.getElementById('audio-waveform-area');
            if (waveArea) {
                if (originalAudioBuffer !== lastAudioBuffer) {
                    lastAudioBuffer = originalAudioBuffer;
                    waveArea.style.opacity = ''; 
                    waveArea.offsetHeight; 
                    // 🌟 ปรับเวลาเป็น 0.6s และใส่ความนุ่มนวล (cubic-bezier) ให้เหมือนการ์ดเป๊ะ!
                    waveArea.style.animation = 'waveformFadeIn 0.6s cubic-bezier(0.2, 0.8, 0.2, 1) forwards';
                } else {
                    waveArea.style.opacity = '';
                }
            }
        }

function drawChannel(ctx, rawData, width, height, yOffset) {
            const samples = width; 
            const blockSize = Math.floor(rawData.length / samples);
            const middle = yOffset + (height / 2);
            const amp = (height / 2) * 0.85; 

            for (let i = 0; i < samples; i++) {
                let min = 1.0;
                let max = -1.0;
                for (let j = 0; j < blockSize; j++) {
                    const datum = rawData[(i * blockSize) + j];
                    if (datum < min) min = datum;
                    if (datum > max) max = datum;
                }
                max = Math.min(1, max * 1.5);
                min = Math.max(-1, min * 1.5);

                const y = middle + (min * amp);
                const h = Math.max(1, (max - min) * amp);
                ctx.fillRect(i, y, 1, h);
            }
        }

function updatePlayheadUI() {
            if (!audioPlayer.paused) {
                if (audioPlayer.duration) {
                    const percent = (audioPlayer.currentTime / audioPlayer.duration) * 100;
                    
                    const playhead = document.getElementById('audio-playhead');
                    if(playhead) playhead.style.left = percent + '%';
                    
                    const audioCurTime = document.getElementById('audio-current-time');
                    if(audioCurTime) audioCurTime.innerText = formatTimeDetailed(audioPlayer.currentTime);
                }
                animationFrameId = requestAnimationFrame(updatePlayheadUI); 
            }
        }

function setupAudioPlayer() {
            audioPlayer.addEventListener('loadedmetadata', () => { 
                const audioDur = document.getElementById('audio-duration');
                if(audioDur) audioDur.innerText = formatTimeDetailed(audioPlayer.duration);
            });
            audioPlayer.addEventListener('play', () => {
                document.getElementById('icon-play').style.display = 'none';
                document.getElementById('icon-pause').style.display = 'block';
                const playhead = document.getElementById('audio-playhead');
                if (playhead) playhead.style.opacity = '1';
                requestAnimationFrame(updatePlayheadUI); 
            });
            audioPlayer.addEventListener('pause', () => {
                document.getElementById('icon-play').style.display = 'block';
                document.getElementById('icon-pause').style.display = 'none';
                cancelAnimationFrame(animationFrameId);
                const playhead = document.getElementById('audio-playhead');
                if (playhead && audioPlayer.currentTime < 0.05) playhead.style.opacity = '0'; 
            });
            audioPlayer.addEventListener('ended', () => {
                
                const audioCurTime = document.getElementById('audio-current-time');
                if(audioCurTime) audioCurTime.innerText = '00:00:00';
            });
        }

function formatTimeDetailed(seconds) {
            const m = Math.floor(seconds / 60);
            const s = Math.floor(seconds % 60);
            const ms = Math.floor((seconds % 1) * 100);
            return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}:${ms.toString().padStart(2, '0')}`;
        }

function audioBufferToWavBlob(buffer) {
            const numOfChan = buffer.numberOfChannels;
            const length = buffer.length * numOfChan * 2 + 44;
            const out = new ArrayBuffer(length);
            const view = new DataView(out);
            const channels = [];
            let sample;
            let offset = 0;
            let pos = 0;

            function setUint16(data) { view.setUint16(offset, data, true); offset += 2; }
            function setUint32(data) { view.setUint32(offset, data, true); offset += 4; }

            setUint32(0x46464952); setUint32(length - 8); setUint32(0x45564157); 
            setUint32(0x20746d66); setUint32(16); setUint16(1); setUint16(numOfChan);
            setUint32(buffer.sampleRate); setUint32(buffer.sampleRate * 2 * numOfChan); 
            setUint16(numOfChan * 2); setUint16(16); setUint32(0x61746164); setUint32(length - offset - 4); 

            for (let i = 0; i < buffer.numberOfChannels; i++) channels.push(buffer.getChannelData(i));
            while (pos < buffer.length) {
                for (let i = 0; i < numOfChan; i++) {
                    sample = Math.max(-1, Math.min(1, channels[i][pos]));
                    sample = Math.trunc(0.5 + sample < 0 ? sample * 32768 : sample * 32767);
                    view.setInt16(offset, sample, true);
                    offset += 2;
                }
                pos++;
            }
            return new Blob([out], { type: "audio/wav" });
        }

async function toggleReverse() {
            const reverseCheck = document.getElementById('reverse-checkbox');
            const isRev = reverseCheck.checked;
            const waveformArea = document.getElementById('audio-waveform-area');
            
            if (isRev) { waveformArea.style.transform = 'scaleX(-1)'; } 
            else { waveformArea.style.transform = 'none'; }

            if (!originalAudioBuffer) return;

            const wasPlaying = !audioPlayer.paused;
            const currentTime = audioPlayer.currentTime;
            const duration = audioPlayer.duration;
            audioPlayer.pause();

            if (isRev) {
                if (!reversedBlobUrl) {
                    const ctx = getAudioContext();
                    const reversedBuffer = ctx.createBuffer(originalAudioBuffer.numberOfChannels, originalAudioBuffer.length, originalAudioBuffer.sampleRate);
                    for (let i = 0; i < originalAudioBuffer.numberOfChannels; i++) {
                        const dest = reversedBuffer.getChannelData(i);
                        const src = originalAudioBuffer.getChannelData(i);
                        for (let j = 0; j < src.length; j++) dest[j] = src[src.length - 1 - j];
                    }
                    reversedBlobUrl = URL.createObjectURL(audioBufferToWavBlob(reversedBuffer));
                }
                audioPlayer.src = reversedBlobUrl;
            } else {
                audioPlayer.src = "file:///" + currentPlayingFile.fullPath.replace(/\\/g, '/');
            }

            audioPlayer.currentTime = duration ? (duration - currentTime) : 0;
            if (wasPlaying) audioPlayer.play().catch(e => console.warn(e));
        }

function playAsset(fileData, cardElement, autoPlay = true) {
            document.querySelectorAll('.card').forEach(el => el.classList.remove('playing'));
            if(cardElement) cardElement.classList.add('playing');
            currentPlayingFile = fileData;
            
            const btnAdd = document.getElementById('btn-add-selected');
            if(btnAdd) btnAdd.disabled = false;

            const audioSrc = "file:///" + fileData.fullPath.replace(/\\/g, '/');
            const isAudio = ['.wav', '.mp3'].includes(fileData.ext.toLowerCase());
            const panel = document.getElementById('audio-player-panel');
            
            if (panel) {
                if (isAudio) {
                    panel.style.display = 'flex';
                    
                    const revCheck = document.getElementById('reverse-checkbox');
                    if(revCheck) revCheck.checked = false;
                    document.getElementById('audio-waveform-area').style.transform = 'none';
                    if (reversedBlobUrl) { URL.revokeObjectURL(reversedBlobUrl); reversedBlobUrl = null; }
                    
                    loadAndDrawWaveform(fileData.fullPath);
                    
                    if (audioPlayer.src !== audioSrc) audioPlayer.src = audioSrc;
                    
                    if (autoPlay) {
                        audioPlayer.play().catch(e => console.warn(e));
                    } else {
                        audioPlayer.pause();
                        audioPlayer.currentTime = 0; 
                        const playhead = document.getElementById('audio-playhead');
                        if(playhead) {
                            playhead.style.left = '0%';
                            playhead.style.opacity = '0';
                        }
                    }
                } else {
                    panel.style.display = 'none';
                    audioPlayer.pause();
                    audioPlayer.src = ""; 
                }
            }
        }

function closeAudioPanel() {
            const panel = document.getElementById('audio-player-panel');
            if(panel) panel.style.display = 'none';
            audioPlayer.pause();
        }

function togglePlay() {
            if(!currentPlayingFile) return;
            if (audioPlayer.paused) audioPlayer.play();
            else audioPlayer.pause();
        }

function restartAudio() {
            if(audioPlayer && audioPlayer.src) {
                audioPlayer.currentTime = 0;
                audioPlayer.play().catch(e => console.warn(e));
                
                const playhead = document.getElementById('audio-playhead');
        if(playhead) {
            playhead.style.left = '0%';
            playhead.style.opacity = '0';
        }
                const audioCurTime = document.getElementById('audio-current-time');
                if(audioCurTime) audioCurTime.innerText = '00:00:00';
            }
        }

function toggleMute() {
            audioPlayer.muted = !audioPlayer.muted;
            if(audioPlayer.muted) {
                document.getElementById('icon-vol-on').style.display = 'none';
                document.getElementById('icon-vol-off').style.display = 'block';
            } else {
                document.getElementById('icon-vol-on').style.display = 'block';
                document.getElementById('icon-vol-off').style.display = 'none';
            }
        }

function changeVolume(val) { 
            audioPlayer.volume = val; 
            updateSliderFill(document.getElementById('volume-slider'));
        }

function changePitch(val) {
            audioPlayer.preservesPitch = false; 
            if (audioPlayer.mozPreservesPitch !== undefined) audioPlayer.mozPreservesPitch = false;
            if (audioPlayer.webkitPreservesPitch !== undefined) audioPlayer.webkitPreservesPitch = false;
            
            let semitones = parseInt(val, 10);
            audioPlayer.playbackRate = 2 ** (semitones / 12);
            
            const pv = document.getElementById('pitch-value');
            if(pv) pv.innerText = semitones > 0 ? '+' + semitones : semitones;
        }

function resetPitch() {
            const slider = document.getElementById('pitch-slider');
            if(slider) { slider.value = 0; changePitch(0); } 
        }

function seekAudioPanel(e) {
            if(!audioPlayer.duration) return;
            const rect = e.currentTarget.getBoundingClientRect();
            let clickX = e.clientX - rect.left;
            
            const isRev = document.getElementById('reverse-checkbox').checked;
            if(isRev) clickX = rect.width - clickX;
            
            const percentage = clickX / rect.width;
            
            audioPlayer.currentTime = percentage * audioPlayer.duration;
            
            if(audioPlayer.paused) {
                const playhead = document.getElementById('audio-playhead');
            if(playhead) {
                playhead.style.left = (percentage * 100) + '%';
                if (percentage < 0.005 && audioPlayer.paused) {
                    playhead.style.opacity = '0';
                } else {
                    playhead.style.opacity = '1';
                }
            }
                
                const audioCurTime = document.getElementById('audio-current-time');
                if(audioCurTime) audioCurTime.innerText = formatTimeDetailed(audioPlayer.currentTime);
            }
        }

function handleScrub(e, element, totalFrames = 10) {
            const rect = element.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const percent = Math.max(0, Math.min(1, x / rect.width));
            
            const frameIndex = Math.floor(percent * (totalFrames - 1));
            const yPos = frameIndex * 11.1111; 
            element.style.backgroundPosition = `0% ${yPos}%`;
            
            const scrubLine = element.querySelector('.scrub-line');
            if(scrubLine) scrubLine.style.width = (percent * 100) + '%';
        }

function resetScrub(element) {
            // 🌟 ให้กลับมาพักที่เฟรมกลาง (55.55%) เสมอ แทนที่จะกลับไปที่ 0% 🌟
            element.style.backgroundPosition = '0% 55.55%';
            const scrubLine = element.querySelector('.scrub-line');
            if(scrubLine) scrubLine.style.width = '0%';
        }



/* =======================================================
   BLUE BIRD COMPOSER - MEDIA & FFMPEG UTILITIES
======================================================= */

window.previewQueue = window.previewQueue || [];
window.isGenerating = window.isGenerating || false;
window.stopRequested = window.stopRequested || false;

window.triggerContextGeneratePreview = function () {
    document.getElementById('context-menu').style.display = 'none';
    if (!contextTarget) return;

    const path = require('path');
    const folderName = path.basename(contextTarget);

    showCustomDialog(
        'confirm',
        `ต้องการสแกนและสร้างพรีวิวให้โฟลเดอร์ <br><b style="color: var(--accent-color); font-size: 15px;">'${folderName}'</b> ใช่หรือไม่?<br><span style="font-size: 11.5px; color: #888; font-weight: normal; margin-top: 8px; display: inline-block;">(ระบบจะล็อคเป้าสแกนเฉพาะโฟลเดอร์นี้ และข้ามไฟล์ที่มีพรีวิวอยู่แล้วโดยอัตโนมัติ)</span>`,
        '',
        function (isOk) {
            if (isOk) {
                window.pendingFolderToAdd = contextTarget;
                window.isTargetedScan = true; // 👈 ธงบอกสถานะ: ห้ามแอบบันทึกเข้า Library หลักเด็ดขาด!

                if (typeof startGeneratingPreviews === 'function') {
                    startGeneratingPreviews();
                }
            }
        }
    );
};

window.proceedMogrtGeneration = function () {
    document.getElementById('mogrt-warning-modal').style.display = 'none';
    oldStartGenV61(); // ส่งไม้ต่อให้ระบบเดิมทำงาน
};


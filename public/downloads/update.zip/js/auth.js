(() => {
    // Firebase Configuration
    // Note: Security must be enforced via Firebase Security Rules in the Firebase Console.
    const firebaseConfig = {
      apiKey: "AIzaSyCmzjgIsqDv_CFzv4nwd_Zg1j2V79R7Qus",
      authDomain: "blue-bird-pictures-studio.firebaseapp.com",
      projectId: "blue-bird-pictures-studio",
      storageBucket: "blue-bird-pictures-studio.firebasestorage.app",
      messagingSenderId: "627225426708",
      appId: "1:627225426708:web:3c9b8570ab16c1756e6001"
    };
    
    // Initialize Firebase safely
    if (typeof firebase === 'undefined') {
        console.error("Firebase SDK is not loaded. Please check your internet connection.");
        document.addEventListener("DOMContentLoaded", () => {
            const errorMsg = document.getElementById("auth-error");
            const loadingMsg = document.getElementById("auth-loading");
            const formContainer = document.getElementById("auth-form-container");
            if (loadingMsg) loadingMsg.style.display = "none";
            if (formContainer) formContainer.style.display = "block";
            if (errorMsg) {
                errorMsg.innerText = "ไม่สามารถเชื่อมต่อเซิร์ฟเวอร์ได้ กรุณาตรวจสอบอินเทอร์เน็ต (Firebase Load Failed)";
                errorMsg.style.display = "block";
                document.getElementById("auth-modal").style.display = "flex";
            }
        });
        return;
    }
    if (!firebase.apps.length) {
        firebase.initializeApp(firebaseConfig);
    }
    const auth = firebase.auth();
    
    // Simple Email Validator Regex
    const validateEmail = (email) => {
        return String(email)
            .toLowerCase()
            .match(
                /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
            );
    };
    
    document.addEventListener("DOMContentLoaded", () => {
        const authModal = document.getElementById("auth-modal");
        const loginForm = document.getElementById("login-form");
        const emailInput = document.getElementById("auth-email");
        const passwordInput = document.getElementById("auth-password");
        const errorMsg = document.getElementById("auth-error");
        const submitBtn = document.getElementById("auth-submit-btn");
        const togglePwdBtn = document.getElementById("auth-toggle-pwd");
        const eyeShow = document.getElementById("eye-show");
        const eyeHide = document.getElementById("eye-hide");
        const langSelect = document.getElementById("auth-lang-selector");
        const forgotPwdBtn = document.getElementById("auth-forgot-pwd");

        // Sync initial language to the dropdown
        if (langSelect && window.i18n && window.i18n.lang) {
            langSelect.value = window.i18n.lang;
            window.i18n.translateUI(); // Ensure UI is translated on startup
        }
    
        // Handle Forgot Password
        if (forgotPwdBtn) {
            forgotPwdBtn.addEventListener("click", (e) => {
                e.preventDefault();
                const email = emailInput.value.trim();
                if (!email) {
                    errorMsg.textContent = window.i18n ? window.i18n.t('auth_err_empty') : "กรุณากรอกอีเมลและรหัสผ่านให้ครบถ้วน";
                    errorMsg.style.display = 'block';
                    errorMsg.style.color = "#ff4d4f";
                    return;
                }
                if (!validateEmail(email)) {
                    errorMsg.textContent = window.i18n ? window.i18n.t('auth_err_email_format') : "รูปแบบอีเมลไม่ถูกต้อง";
                    errorMsg.style.display = 'block';
                    errorMsg.style.color = "#ff4d4f";
                    return;
                }
                
                fetch('http://localhost:3000/api/auth/send-reset', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        email: email, 
                        locale: window.i18n ? window.i18n.lang : 'th' 
                    })
                })
                .then(async response => {
                    if (!response.ok) {
                        try {
                            const errData = await response.json();
                            throw new Error(errData.error || 'Network response was not ok');
                        } catch (e) {
                            throw new Error('Network response was not ok');
                        }
                    }
                    return response.json();
                })
                .then((data) => {
                    if (data.error) throw new Error(data.error);
                    errorMsg.textContent = window.i18n ? window.i18n.t('auth_reset_sent') : "ส่งลิงก์รีเซ็ตรหัสผ่านไปที่อีเมลของคุณแล้ว";
                    errorMsg.style.display = 'block';
                    errorMsg.style.color = "#52c41a"; // Green for success
                    errorMsg.style.background = "rgba(82, 196, 26, 0.1)";
                    errorMsg.style.borderColor = "rgba(82, 196, 26, 0.3)";
                })
                .catch((error) => {
                    let errMsg = error.message;
                    if (errMsg === 'auth/user-not-found') {
                        errMsg = window.i18n ? window.i18n.t('auth_err_wrong_pwd') : "ไม่พบบัญชีผู้ใช้นี้ในระบบ";
                    }
                    errorMsg.textContent = "เกิดข้อผิดพลาดในการส่งอีเมล กรุณาลองใหม่อีกครั้ง (" + errMsg + ")";
                    errorMsg.style.display = 'block';
                    errorMsg.style.color = "";
                    errorMsg.style.background = "";
                    errorMsg.style.borderColor = "";
                });
            });
        }
    
        // Toggle Password Visibility
        if (togglePwdBtn) {
            togglePwdBtn.addEventListener("click", () => {
                if (passwordInput.type === "password") {
                    passwordInput.type = "text";
                    eyeShow.style.display = "block";
                    eyeHide.style.display = "none";
                } else {
                    passwordInput.type = "password";
                    eyeShow.style.display = "none";
                    eyeHide.style.display = "block";
                }
            });
        }
    
        // Listen to Auth State changes
        auth.onAuthStateChanged((user) => {
            if (user) {
                // User is logged in, hide modal
                if (authModal) authModal.style.opacity = '0';
                setTimeout(() => {
                    if (authModal) authModal.style.display = 'none';
                    
                    // Trigger any initialization needed after login
                    if (typeof initPlugin === 'function') {
                        // Safely restart plugin logic if needed
                    }
    
                    // Check for updates
                    if (typeof checkForUpdates === 'function') {
                        checkForUpdates();
                    }
                }, 300);
            } else {
                // User is logged out, show modal with login form
                const authLoading = document.getElementById("auth-loading");
                const authFormContainer = document.getElementById("auth-form-container");
                const submitBtn = document.getElementById("auth-submit-btn");
                if (authLoading) authLoading.style.display = 'none';
                if (authFormContainer) authFormContainer.style.display = 'block';
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.textContent = window.i18n ? window.i18n.t('auth_login_btn') : "Login";
                }
                if (authModal) {
                    authModal.style.display = 'flex';
                    setTimeout(() => {
                        authModal.style.opacity = '1';
                    }, 10);
                }
            }
        });
    
        // Handle Login Submit
        if (loginForm) {
            loginForm.addEventListener("submit", (e) => {
                e.preventDefault();
                const email = emailInput.value.trim();
                const password = passwordInput.value.trim();
        
                if (!email || !password) {
                    errorMsg.textContent = window.i18n ? window.i18n.t('auth_err_empty') : "กรุณากรอกอีเมลและรหัสผ่านให้ครบถ้วน";
                    errorMsg.style.display = 'block';
                    errorMsg.style.color = "#ff4d4f";
                    return;
                }
        
                if (!validateEmail(email)) {
                    errorMsg.textContent = window.i18n ? window.i18n.t('auth_err_email_format') : "รูปแบบอีเมลไม่ถูกต้อง";
                    errorMsg.style.display = 'block';
                    errorMsg.style.color = "#ff4d4f";
                    return;
                }
        
                submitBtn.disabled = true;
                submitBtn.textContent = window.i18n ? window.i18n.t('auth_logging_in_btn') : "กำลังเข้าสู่ระบบ...";
                errorMsg.style.display = 'none';
        
                auth.signInWithEmailAndPassword(email, password)
                    .then((userCredential) => {
                        // Login success, modal will hide automatically via onAuthStateChanged
                    })
                    .catch((error) => {
                        const errorCode = error.code;
                        
                        if (errorCode === 'auth/network-request-failed') {
                            // Try Node.js fallback test
                            try {
                                const https = require('https');
                                process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
                                const data = JSON.stringify({
                                    email: email,
                                    password: password,
                                    returnSecureToken: true
                                });
                                const req = https.request({
                                    hostname: 'identitytoolkit.googleapis.com',
                                    port: 443,
                                    path: '/v1/accounts:signInWithPassword?key=' + firebaseConfig.apiKey,
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/json',
                                        'Content-Length': data.length
                                    }
                                }, (res) => {
                                    let body = '';
                                    res.on('data', d => body += d);
                                    res.on('end', () => {
                                        if (res.statusCode === 200) {
                                            errorMsg.textContent = "Node.js สามารถเชื่อมต่อได้ แต่ Firebase SDK ถูกบล็อก (ปัญหาที่ระบบ Chromium ของ Premiere)";
                                        } else {
                                            errorMsg.textContent = "Node.js เชื่อมต่อได้ แต่ส่งคืน Error: " + res.statusCode + " " + body;
                                        }
                                        errorMsg.style.display = 'block';
                                        submitBtn.disabled = false;
                                        submitBtn.textContent = window.i18n ? window.i18n.t('auth_login_btn') : "Login";
                                    });
                                });
                                req.on('error', (e) => {
                                    errorMsg.textContent = "Node.js ก็เชื่อมต่อไม่ได้: " + e.message;
                                    errorMsg.style.display = 'block';
                                    submitBtn.disabled = false;
                                    submitBtn.textContent = window.i18n ? window.i18n.t('auth_login_btn') : "Login";
                                });
                                req.write(data);
                                req.end();
                            } catch (e) {
                                errorMsg.textContent = "Node.js fallback failed: " + e.message;
                                errorMsg.style.display = 'block';
                                submitBtn.disabled = false;
                                submitBtn.textContent = window.i18n ? window.i18n.t('auth_login_btn') : "Login";
                            }
                            return; // Stop here, since we are handling it asynchronously
                        } else if (errorCode === 'auth/wrong-password' || errorCode === 'auth/user-not-found' || errorCode === 'auth/invalid-credential') {
                            errorMsg.textContent = window.i18n ? window.i18n.t('auth_err_wrong_pwd') : "อีเมลหรือรหัสผ่านไม่ถูกต้อง";
                        } else if (errorCode === 'auth/invalid-email') {
                            errorMsg.textContent = window.i18n ? window.i18n.t('auth_err_email_format') : "รูปแบบอีเมลไม่ถูกต้อง";
                        } else if (errorCode === 'auth/too-many-requests') {
                            errorMsg.textContent = window.i18n ? window.i18n.t('auth_err_too_many') : "พยายามเข้าสู่ระบบล้มเหลวหลายครั้งเกินไป กรุณารอสักครู่แล้วลองใหม่";
                        } else {
                            errorMsg.textContent = (window.i18n ? window.i18n.t('auth_err_general') : "เกิดข้อผิดพลาดในการล็อคอิน กรุณาลองใหม่อีกครั้ง") + " (" + errorCode + ")";
                        }
                        
                        errorMsg.style.display = 'block';
                        errorMsg.style.color = "";
                        errorMsg.style.background = "";
                        errorMsg.style.borderColor = "";
                        submitBtn.disabled = false;
                        submitBtn.textContent = window.i18n ? window.i18n.t('auth_login_btn') : "Login";
                    });
            });
        }
        // Handle Google Sign-in via External Browser
        const googleBtn = document.getElementById("auth-google-btn");
        if (googleBtn) {
            googleBtn.addEventListener("click", () => {
                const http = require('http');
                const url = require('url');
                
                // Show loading state
                errorMsg.style.display = 'none';
                googleBtn.disabled = true;
                const originalText = googleBtn.innerHTML;
                googleBtn.innerHTML = 'กำลังรอการยืนยันจากเบราว์เซอร์...';

                const server = http.createServer((req, res) => {
                    const query = url.parse(req.url, true).query;
                    if (query.token) {
                        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
                        res.end(`
                            <html>
                            <head><title>เข้าสู่ระบบสำเร็จ</title></head>
                            <body style="background: #1e1e1e; color: #fff; display: flex; justify-content: center; align-items: center; height: 100vh; font-family: sans-serif; text-align: center;">
                                <div>
                                    <h1 style="color: #22c55e;">✅ เข้าสู่ระบบสำเร็จ</h1>
                                    <p style="color: #aaa;">กำลังส่งข้อมูลกลับไปยัง Blue Bird Composer</p>
                                    <p style="font-size: 14px; color: #666;">กรุณาปิดหน้าต่างนี้และกลับไปที่โปรแกรม Premiere Pro</p>
                                </div>
                                <script>setTimeout(() => window.close(), 3000);</script>
                            </body>
                            </html>
                        `);
                        server.close();
                        
                        // Proceed with login
                        auth.signInWithCustomToken(query.token)
                            .then(() => {
                                console.log("Logged in via custom token from browser!");
                                // Login success, modal will hide automatically via onAuthStateChanged
                            })
                            .catch((error) => {
                                errorMsg.textContent = "ล็อกอินผ่าน Google ล้มเหลว: " + error.message;
                                errorMsg.style.display = 'block';
                                googleBtn.disabled = false;
                                googleBtn.innerHTML = originalText;
                            });
                    } else {
                        res.writeHead(400, { 'Content-Type': 'text/plain' });
                        res.end('No token provided.');
                        server.close();
                        googleBtn.disabled = false;
                        googleBtn.innerHTML = originalText;
                    }
                });

                // Listen on random port
                server.listen(0, '127.0.0.1', () => {
                    const port = server.address().port;
                    const callbackUrl = `http://127.0.0.1:${port}`;
                    
                    // URL for development/testing
                    const authUrl = `http://localhost:3000/th/plugin-auth?callback=${encodeURIComponent(callbackUrl)}`;
                    
                    // To switch to production:
                    // const authUrl = `https://bluebirdpicturesstudio.com/th/plugin-auth?callback=${encodeURIComponent(callbackUrl)}`;
                    
                    if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) {
                        window.cep.util.openURLInDefaultBrowser(authUrl);
                    } else {
                        try {
                            require('child_process').exec(`start "" "${authUrl}"`);
                        } catch (e) {
                            window.open(authUrl, "_blank");
                        }
                    }
                });

                // Timeout safety
                setTimeout(() => {
                    if (server.listening) {
                        server.close();
                        googleBtn.disabled = false;
                        googleBtn.innerHTML = originalText;
                        if (errorMsg.style.display === 'none') {
                            errorMsg.textContent = "หมดเวลาการยืนยัน กรุณาลองใหม่อีกครั้ง";
                            errorMsg.style.display = 'block';
                        }
                    }
                }, 120000); // 2 minutes timeout
            });
        }
    });

    // Global function to open sign up URL in default browser
    window.openSignupUrl = function(e) {
        if(e) e.preventDefault();
        const url = "https://bluebirdpicturesstudio.com";
        if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) {
            window.cep.util.openURLInDefaultBrowser(url);
        } else {
            window.open(url, "_blank");
        }
    };
})();

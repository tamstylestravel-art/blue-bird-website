// --- ui-core.js ---

function renderGrid() {
            const grid = document.getElementById('asset-grid');
            grid.innerHTML = ''; 
            
            const searchTerm = document.getElementById('search').value.toLowerCase().trim();

            if (!currentSelectedDir && searchTerm === '') {
                grid.innerHTML = '<p style="grid-column: 1 / -1; text-align: center; color: var(--text-light); margin-top: 40px;">โปรดเลือกโฟลเดอร์ หรือพิมพ์เพื่อค้นหาไฟล์</p>';
                return;
            }

            // 🌟 ระบบค้นหาครอบจักรวาล (Global Search) 🌟
            const filtered = allFiles.filter(file => {
                const matchSearch = file.name.toLowerCase().includes(searchTerm);
                if (searchTerm !== '') {
                    return matchSearch; 
                } else {
                    return file.dir === currentSelectedDir; 
                }
            });

            if (filtered.length === 0) {
                grid.innerHTML = '<p style="grid-column: 1 / -1; text-align: center; color: var(--text-light); margin-top: 40px;">ไม่พบไฟล์สื่อที่ต้องการ</p>';
                return;
            }

            filtered.forEach(file => {
                const card = document.createElement('div');
                card.className = `card`;
                
                const previewDir = path.join(file.dir, '_Blue Bird Previews');
                const previewImg = path.join(previewDir, file.name + '.png');
                const hasPreview = fs.existsSync(previewImg);
                
                const isVideo = ['.mp4', '.mov'].includes(file.ext.toLowerCase());
                const isGraphic = file.ext.toLowerCase() === '.mogrt';
                const isImage = ['.jpg', '.jpeg', '.png'].includes(file.ext.toLowerCase());
            
                const hasScrub = isVideo || isGraphic;

                let bgStyle = '';
                if (isImage) {
                    bgStyle = `background-image: url('file:///${file.fullPath.replace(/\\/g, '/')}?t=${Date.now()}'); background-size: cover; background-position: center; background-color: var(--waveform-bg);`;
                } else if (hasPreview) {
                    if (hasScrub) {
                        bgStyle = `background-image: url('file:///${previewImg.replace(/\\/g, '/')}?t=${Date.now()}'); background-size: 100% 1000%; background-position: 0% 55.55%;`;
                    } else {
                        bgStyle = `background-image: url('file:///${previewImg.replace(/\\/g, '/')}?t=${Date.now()}'); background-size: 100% 100%; background-position: center; background-color: var(--waveform-bg);`;
                    }
                }
                
                if(currentPlayingFile && currentPlayingFile.fullPath === file.fullPath) {
                    card.classList.add('playing');
                }

                let badgeClass = isVideo ? 'badge video' : (isGraphic ? 'badge mogrt' : (isImage ? 'badge image' : 'badge audio'));
                let badgeText = isVideo ? 'VIDEO' : (isGraphic ? 'MOGRT' : (isImage ? 'IMAGE' : 'AUDIO'));
                
                let iconPlaceholder = (hasPreview || isImage) ? '' : `<div class="icon-center">${isVideo ? '🎬' : (isGraphic ? '📝' : '🎵')}</div>`;

                const scrubLineHtml = hasScrub ? `<div class="scrub-line"></div>` : '';
                const mouseEvents = hasScrub ? `onmousemove="handleScrub(event, this, 10)" onmouseleave="resetScrub(this)" style="cursor: ew-resize;"` : `style="cursor: pointer;"`;
                card.innerHTML = `
                    <div class="card-waveform-container">
                        <div class="card-waveform" style="${bgStyle}" ${mouseEvents}>
                            ${iconPlaceholder}
                            ${scrubLineHtml}
                        </div>
                    </div>
                    <div class="card-info">
                        <div class="card-title" title="${file.name}">${file.name}</div>
                        <span class="${badgeClass}">${badgeText}</span>
                    </div>
                `;
                let clickTimer = null;
                card.onclick = (e) => {
                    if (clickTimer) clearTimeout(clickTimer);
                    clickTimer = setTimeout(() => {
                        playAsset(file, card, true); 
                    }, 250);
                };
                
                card.ondblclick = (e) => {
                    if (clickTimer) clearTimeout(clickTimer);
                    playAsset(file, card, false); 
                    addSelectedToTimeline(); 
                };

                grid.appendChild(card);
            });

            // 🚀 พระเอกอยู่ตรงนี้: สั่งให้การ์ดยืดออกจนเต็มพื้นที่แบบสมูทๆ ทุกครั้งที่มีการโหลดหน้าใหม่ 🚀
            setTimeout(() => {
                if (typeof changeGridSize === "function") {
                    changeGridSize(document.getElementById('size-slider').value);
                }
            }, 10);
        }

function changeGridSize(size) {
            const grid = document.getElementById('asset-grid');
            const cards = document.querySelectorAll('.card');
            
            if (!grid || cards.length === 0) return;

            let containerWidth = grid.clientWidth - 40; 
            if (containerWidth <= 0) {
                const sidebarWidth = document.getElementById('sidebar').offsetWidth || 260;
                containerWidth = window.innerWidth - sidebarWidth - 40;
            }

            const gap = 15; 
            let targetSize = parseInt(size);
            
            let cols = Math.floor((containerWidth + gap) / (targetSize + gap));
            if (cols < 1) cols = 1; 

            let exactWidth = Math.floor(((containerWidth - ((cols - 1) * gap)) / cols)) - 0.5;

            cards.forEach(card => {
                card.style.width = exactWidth + 'px';
            });
        }

function toggleNode(element) {
            const currentFolderLabel = element.closest('.folder-label');
            if (!currentFolderLabel) return;
            
            const childrenContainer = currentFolderLabel.nextElementSibling;
            
            if (childrenContainer?.tagName === 'UL') {
                const isHidden = childrenContainer.style.display === 'none';
                
                // 🚀 โหมด Accordion (หุบร่มอัตโนมัติ) ฉบับเสถียร 🚀
                if (isHidden) { 
                    const parentItem = currentFolderLabel.parentElement; 
                    const parentList = parentItem.parentElement; 
                    
                    if(parentList) {
                        Array.from(parentList.children).forEach(child => {
                            // หาเฉพาะโฟลเดอร์เพื่อนบ้านในชั้นเดียวกันที่กำลังกางอยู่
                            if (child !== parentItem && (child.classList.contains('tree-root') || child.classList.contains('tree-node'))) {
                                const label = child.querySelector(':scope > .folder-label'); // บังคับหาเฉพาะลูกตรงๆ
                                if (label) {
                                    const caret = label.querySelector('.caret');
                                    const ul = label.nextElementSibling;
                                    if (caret?.classList.contains('caret-down')) {
                                        caret.classList.remove('caret-down');
                                        if (ul?.tagName === 'UL') ul.style.display = 'none';
                                        expandedFolders.delete(label.dataset.path);
                                    }
                                }
                            }
                        });
                    }
                }

                // สลับสถานะ (กาง/หุบ) ให้โฟลเดอร์ที่เรากำลังคลิก
                childrenContainer.style.display = isHidden ? 'block' : 'none';
                element.classList.toggle('caret-down', isHidden);
                
                const path = currentFolderLabel.dataset.path;
                if (isHidden) {
                    expandedFolders.add(path);
                } else {
                    expandedFolders.delete(path);
                }
            }
        }

function getUserAvatarHtml(size = 24, fontSize = 12) {
    if (typeof firebase !== 'undefined' && firebase.apps.length > 0 && firebase.auth().currentUser) {
        const u = firebase.auth().currentUser;
        if (u.photoURL) {
            return `<img src="${u.photoURL}" style="width:100%; height:100%; object-fit:cover; border-radius:50%;" />`;
        } else {
            let char = 'U';
            if (u.displayName) {
                char = u.displayName.charAt(0).toUpperCase();
            } else if (u.email) {
                char = u.email.charAt(0).toUpperCase();
            }
            return `<div style="width:100%; height:100%; border-radius:50%; background:linear-gradient(135deg, #00b4db, #0083b0); color:white; display:flex; align-items:center; justify-content:center; font-weight:bold; font-size:${fontSize}px;">${char}</div>`;
        }
    }
    return `<svg viewBox="0 0 24 24" fill="currentColor" style="width:14px; height:14px;"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>`;
}

function showAboutCreator() {
            let email = "guest@bluebird.com";
            let displayName = "";
            let avatarHtml = `<div style="width: 90px; height: 90px; border-radius: 50%; background: linear-gradient(135deg, #00b4db, #0083b0); color: white; display: flex; align-items: center; justify-content: center; font-size: 40px; font-weight: bold; margin: 0 auto 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); border: 3px solid #333;">G</div>`;
            
            if (typeof firebase !== 'undefined' && firebase.apps.length > 0 && firebase.auth().currentUser) {
                const u = firebase.auth().currentUser;
                email = u.email;
                displayName = u.displayName || "";
                
                if (u.photoURL) {
                    avatarHtml = `<div style="width: 90px; height: 90px; border-radius: 50%; margin: 0 auto 15px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.5); border: 3px solid #333;"><img src="${u.photoURL}" style="width:100%; height:100%; object-fit:cover;" /></div>`;
                } else {
                    const char = displayName ? displayName.charAt(0).toUpperCase() : email.charAt(0).toUpperCase();
                    avatarHtml = `<div style="width: 90px; height: 90px; border-radius: 50%; background: linear-gradient(135deg, #00b4db, #0083b0); color: white; display: flex; align-items: center; justify-content: center; font-size: 40px; font-weight: bold; margin: 0 auto 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); border: 3px solid #333;">${char}</div>`;
                }
            }
            const htmlContent = `
                <style>
                    #custom-prompt-ok, #custom-prompt-cancel { display: none !important; }
                    #custom-prompt-title { border-bottom: none !important; padding-bottom: 0 !important; margin-bottom: 0 !important; }
                    .about-creator-close {
                        position: absolute;
                        top: -10px;
                        right: -10px;
                        background: transparent;
                        border: none;
                        color: #888;
                        font-size: 24px;
                        cursor: pointer;
                        transition: color 0.2s, transform 0.2s;
                        line-height: 1;
                    }
                    .about-creator-close:hover {
                        color: #fff;
                        transform: scale(1.1);
                    }
                    .btn-logout {
                        background: linear-gradient(135deg, #ff416c, #ff4b2b);
                        color: white;
                        border: none;
                        padding: 12px 16px;
                        border-radius: 8px;
                        cursor: pointer;
                        font-size: 14px;
                        font-weight: 500;
                        width: 100%;
                        transition: all 0.3s ease;
                        box-shadow: 0 4px 15px rgba(255, 65, 108, 0.3);
                        font-family: 'Mitr', sans-serif;
                    }
                    .btn-logout:hover {
                        box-shadow: 0 6px 20px rgba(255, 65, 108, 0.5);
                        transform: translateY(-2px);
                    }
                    .btn-portal {
                        background: linear-gradient(45deg, #00b4db, #0083b0);
                        color: white;
                        border: none;
                        padding: 12px 25px;
                        border-radius: 8px;
                        cursor: pointer;
                        font-size: 14px;
                        font-weight: 500;
                        width: 100%;
                        margin-bottom: 10px;
                        transition: all 0.3s ease;
                        box-shadow: 0 4px 15px rgba(0, 180, 219, 0.3);
                        font-family: 'Mitr', sans-serif;
                    }
                    .btn-portal:hover {
                        box-shadow: 0 6px 20px rgba(0, 180, 219, 0.5);
                        transform: translateY(-2px);
                    }
                </style>
                <div style="text-align:center; padding: 5px 0; position: relative;">
                    <button class="about-creator-close" onclick="closeCustomDialog()">×</button>
                    ${avatarHtml}
                    ${displayName ? `<h3 style="margin:0 0 5px 0; color:#ffffff; font-size:20px; font-weight: 600;">${displayName}</h3>` : ''}
                    <h3 style="margin:0 0 8px 0; color:#a0a0a0; font-size:14px; font-weight:normal;">${email}</h3>
                    <p style="margin:0 0 25px 0; color:#a0a0a0; font-size:13px; letter-spacing: 0.5px;">Blue Bird Composer <span style="color:#00b4db; font-weight: bold;">PRO</span></p>
                    <button class="btn-portal" onclick="openWebPortal()">
                        เข้าสู่หน้าสมาชิก (Dashboard)
                    </button>
                    <button class="btn-logout" onclick="logoutUser()">
                        ออกจากระบบ (Logout)
                    </button>
                </div>
            `;
            showCustomDialog('alert', htmlContent, "");
        }

        function openWebPortal() {
            closeCustomDialog();
            const url = "https://bluebirdpicturesstudio.com/th/dashboard";
            try {
                const cp = require('node:child_process');
                const cmd = navigator.platform.toLowerCase().includes('win') ? 'start "" "' + url + '"' : 'open "' + url + '"';
                cp.exec(cmd);
            } catch (e) {
                console.warn("Failed to open URL via child_process, falling back to CEP/Browser", e);
                if (window.cep?.utils?.openURLInDefaultBrowser) {
                    window.cep.utils.openURLInDefaultBrowser(url);
                } else {
                    window.open(url, "_blank", "noopener,noreferrer");
                }
            }
        }

        function logoutUser() {
            closeCustomDialog();
            if (typeof firebase !== 'undefined') {
                firebase.auth().signOut().then(() => {
                    console.log("Logged out successfully");
                }).catch((error) => {
                    console.error("Logout error", error);
                });
            }
        }

function closeCustomDialog() { document.getElementById('custom-prompt-modal').style.display = 'none'; }

function submitCustomDialog() {
            closeCustomDialog();
            if (customPromptCallback) {
                const isPrompt = document.getElementById('custom-prompt-input').style.display !== 'none';
                customPromptCallback(isPrompt ? document.getElementById('custom-prompt-input').value : true);
            }
        }

function showCustomDialog(type, message, defaultValue, callback) {
            document.getElementById('custom-prompt-title').innerHTML = message;
            const input = document.getElementById('custom-prompt-input');
            const cancelBtn = document.getElementById('custom-prompt-cancel');
            input.style.display = type === 'prompt' ? 'block' : 'none';
            cancelBtn.style.display = type === 'alert' ? 'none' : 'block';
            if(type === 'prompt') input.value = defaultValue;
            document.getElementById('custom-prompt-modal').style.display = 'flex';
            customPromptCallback = callback;
            if(type === 'prompt') setTimeout(() => input.focus(), 100);
        }

function showContextMenu(e, targetPath, element, type = 'folder') {
            e.preventDefault(); contextTarget = targetPath; contextTargetType = type; 
            let removeBtn = document.getElementById('menu-remove-btn');
            let colorPicker = document.querySelector('.color-picker-row');
            let divider = document.querySelector('.context-divider');
            let showInExpBtn = document.querySelector('.context-item[onclick="showInExplorer()"]');
            let setCoverBtn = document.getElementById('menu-set-cover-btn');
            let deleteCoverBtn = document.getElementById('menu-delete-cover-btn'); // 👈 เพิ่มระบบปุ่มลบปก
            
            if (type === 'main-library') {
                // 🛑 ถ้าเป็นไลบรารี่หลัก ไม่ต้องเปิดเมนูเลย ให้หยุดทำงานทันที (แก้บั๊กกล่องดำเปล่าๆ)
                const menu = document.getElementById('context-menu');
                if (menu) { menu.style.display = 'none'; }
                return;
            } else if (type === 'sub-library') {
                if (showInExpBtn) { showInExpBtn.style.display = 'none'; }
                if (removeBtn) { removeBtn.style.display = 'block'; removeBtn.innerText = "Delete Library"; }
                if (colorPicker) { colorPicker.style.display = 'none'; }
                if (divider) { divider.style.display = 'none'; }
                if (setCoverBtn) { setCoverBtn.style.display = 'none'; }
                if (deleteCoverBtn) { deleteCoverBtn.style.display = 'none'; }
            } else if (type === 'file') {
                if (showInExpBtn) { showInExpBtn.style.display = 'block'; }
                if (removeBtn) { removeBtn.style.display = 'none'; }
                if (colorPicker) { colorPicker.style.display = 'none'; }
                if (divider) { divider.style.display = 'none'; }
                if (setCoverBtn) { setCoverBtn.style.display = 'none'; }
                if (deleteCoverBtn) { deleteCoverBtn.style.display = 'none'; }
            } else if (type === 'main-folder') {
                if (showInExpBtn) { showInExpBtn.style.display = 'block'; }
                if (removeBtn) { removeBtn.style.display = 'block'; removeBtn.innerText = "Remove from User Library"; }
                if (colorPicker) { colorPicker.style.display = 'flex'; }
                if (divider) { divider.style.display = 'block'; }
                if (setCoverBtn) { setCoverBtn.style.display = 'block'; }
                if (deleteCoverBtn) { deleteCoverBtn.style.display = fs.existsSync(path.join(targetPath, '_album_cover.jpg')) ? 'block' : 'none'; }
            } else {
                if (showInExpBtn) { showInExpBtn.style.display = 'block'; }
                if (removeBtn) { removeBtn.style.display = 'none'; }
                if (colorPicker) { colorPicker.style.display = 'none'; }
                if (divider) { divider.style.display = 'none'; }
                if (setCoverBtn) { setCoverBtn.style.display = 'block'; }
                if (deleteCoverBtn) { deleteCoverBtn.style.display = fs.existsSync(path.join(targetPath, '_album_cover.jpg')) ? 'block' : 'none'; }
            }
            const menu = document.getElementById('context-menu');
            menu.style.display = 'block';
            menu.style.left = Math.min(e.pageX, window.innerWidth - 230) + 'px';
            menu.style.top = Math.min(e.pageY, window.innerHeight - 150) + 'px';
        }

function triggerSetCover() {
            document.getElementById('context-menu').style.display = 'none';
            alert("เตรียมเข้าสู่ระบบตั้งภาพปกของโฟลเดอร์: \n" + contextTarget);
        }


function injectSettingsButton() {
            const topNav = document.querySelector('.top-nav-bar');
            
            // เช็คว่ามีแถบเมนูด้านบน และยังไม่มีปุ่มฟันเฟือง ค่อยสร้างเพิ่มเข้าไป
            if (topNav && !document.getElementById('settings-btn-main')) {
                const settingsBtn = document.createElement('button');
                settingsBtn.id = 'settings-btn-main';
                
                // ใช้ Class 'user-btn' เพื่อให้หน้าตาปุ่มเหมือนกับปุ่ม User เป๊ะๆ
                settingsBtn.className = 'user-btn'; 
                settingsBtn.title = 'Settings (ตั้งค่า)';
                
                // 🛑 ฟังก์ชันเตรียมไว้สำหรับอนาคต (ตอนนี้ให้เด้งแจ้งเตือนก่อน)
                settingsBtn.onclick = () => { 
                    alert("⚙️ ระบบตั้งค่ากำลังพัฒนา... เผื่อพื้นที่ไว้สำหรับอัปเดตฟีเจอร์ใหม่ๆ ในอนาคตครับ!"); 
                };
                
                // วาด SVG รูปฟันเฟืองแบบมินิมอล
                settingsBtn.innerHTML = `
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M19.14,12.94c0.04-0.3,0.06-0.61,0.06-0.94c0-0.32-0.02-0.64-0.06-0.94l2.03-1.58c0.18-0.14,0.23-0.41,0.12-0.61 l-1.92-3.32c-0.12-0.22-0.37-0.29-0.59-0.22l-2.39,0.96c-0.5-0.38-1.03-0.7-1.62-0.94L14.4,2.81c-0.04-0.24-0.24-0.41-0.48-0.41 h-3.84c-0.24,0-0.43,0.17-0.47,0.41L9.25,5.35C8.66,5.59,8.12,5.92,7.63,6.29L5.24,5.33c-0.22-0.08-0.47,0-0.59,0.22L2.73,8.87 C2.62,9.08,2.66,9.34,2.86,9.48l2.03,1.58C4.84,11.36,4.8,11.69,4.8,12s0.02,0.64,0.06,0.94l-2.03,1.58 c-0.18,0.14-0.23,0.41-0.12,0.61l1.92,3.32c0.12,0.22,0.37,0.29,0.59,0.22l2.39-0.96c0.5,0.38,1.03,0.7,1.62,0.94l0.36,2.54 c0.05,0.24,0.24,0.41,0.48,0.41h3.84c0.24,0,0.44-0.17,0.47-0.41l0.36-2.54c0.59-0.24,1.13-0.56,1.62-0.94l2.39,0.96 c0.22,0.08,0.47,0,0.59-0.22l1.92-3.32c0.12-0.22,0.07-0.49-0.12-0.61L19.14,12.94z M12,15.6c-1.98,0-3.6-1.62-3.6-3.6 s1.62-3.6,3.6-3.6s3.6,1.62,3.6,3.6S13.98,15.6,12,15.6z"/>
                    </svg>
                `;
                
                // ดันปุ่มไปต่อท้ายสุด (หลังปุ่ม User)
                topNav.appendChild(settingsBtn);
            }
        }



function injectAutoPreviewButton() {
            const topNav = document.querySelector('.top-nav-bar');
            const settingsBtn = document.getElementById('settings-btn-main'); 
            
            if (topNav && !document.getElementById('auto-preview-btn')) {
                const autoBtn = document.createElement('button');
                autoBtn.id = 'auto-preview-btn';
                autoBtn.title = 'Auto Motion Preview (เล่นพรีวิวอัตโนมัติ)';
                if (window.isAutoPreviewEnabled) autoBtn.classList.add('active');
                
                autoBtn.onclick = window.toggleAutoPreview;
                
                // ไอคอนรูปฟิล์ม/เพลย์แบบวนลูป
                autoBtn.innerHTML = `
                    <svg viewBox="0 0 24 24">
                        <path d="M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3z"/>
                    </svg>
                `;
                
                if (settingsBtn) {
                    topNav.insertBefore(autoBtn, settingsBtn);
                } else {
                    topNav.appendChild(autoBtn);
                }
            }
        }




(function() {
    function showErrorModal(errorDetails) {
        if (document.getElementById('bluebird-error-modal')) return;

        const style = document.createElement('style');
        style.innerHTML = `
            #bluebird-error-modal {
                position: fixed;
                top: 0; left: 0; width: 100vw; height: 100vh;
                background-color: rgba(0, 0, 0, 0.85);
                z-index: 999999;
                display: flex;
                align-items: center;
                justify-content: center;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif, 'Mitr';
                backdrop-filter: blur(5px);
            }
            .bb-error-box {
                background-color: #1e1e1e;
                border: 1px solid #ef4444;
                border-top: 5px solid #ef4444;
                border-radius: 6px;
                padding: 25px;
                width: 90%;
                max-width: 600px;
                color: #e0e0e0;
                box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            }
            .bb-error-title {
                color: #ef4444;
                font-size: 20px;
                font-weight: bold;
                margin-top: 0;
                margin-bottom: 10px;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .bb-error-subtitle {
                font-size: 14px;
                color: #a0a0a0;
                margin-bottom: 20px;
            }
            .bb-error-log {
                background: #111;
                padding: 15px;
                border-radius: 4px;
                font-family: monospace;
                font-size: 12px;
                white-space: pre-wrap;
                word-wrap: break-word;
                max-height: 250px;
                overflow-y: auto;
                border: 1px solid #333;
                color: #fca5a5;
                margin-bottom: 20px;
            }
            .bb-error-btn {
                background-color: #ef4444;
                color: white;
                border: none;
                padding: 10px 20px;
                font-size: 14px;
                border-radius: 4px;
                cursor: pointer;
                font-weight: bold;
                transition: background-color 0.2s;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            .bb-error-btn:hover {
                background-color: #dc2626;
            }
        `;
        document.head.appendChild(style);

        const modal = document.createElement('div');
        modal.id = 'bluebird-error-modal';

        const logText = `Blue Bird Composer Crash Log\n` +
                        `Time: ${new Date().toLocaleString()}\n` +
                        `OS/Browser: ${navigator.userAgent}\n` +
                        `---------------------------------\n` +
                        `${errorDetails}`;

        modal.innerHTML = `
            <div class="bb-error-box">
                <h2 class="bb-error-title">${window.i18n ? window.i18n.t('error_title') : '⚠️ เกิดข้อผิดพลาดร้ายแรง (Critical Error)'}</h2>
                <div class="bb-error-subtitle">${window.i18n ? window.i18n.t('error_subtitle') : 'ปลั๊กอินพบปัญหาที่ไม่สามารถทำงานต่อได้ โปรดคัดลอกข้อมูลด้านล่างแล้วส่งให้ทีมพัฒนา'}</div>
                <div class="bb-error-log" id="bb-error-log-content">${errorDetails}</div>
                <button class="bb-error-btn" id="bb-error-copy-btn">${window.i18n ? window.i18n.t('error_copy') : '📋 คัดลอกข้อมูลแจ้งปัญหา (Copy Log)'}</button>
            </div>
        `;

        // Wait until document body exists (in case error happens in <head>)
        const interval = setInterval(() => {
            if (document.body) {
                document.body.appendChild(modal);
                clearInterval(interval);
                
                document.getElementById('bb-error-copy-btn').addEventListener('click', function(e) {
                    const btn = e.target;
                    // Fallback using textarea for older Chromium/CEP environments
                    const textArea = document.createElement("textarea");
                    textArea.value = logText;
                    document.body.appendChild(textArea);
                    textArea.select();
                    try {
                        document.execCommand('copy');
                        btn.innerHTML = window.i18n ? window.i18n.t('error_copied') : '✅ คัดลอกเรียบร้อยแล้ว!';
                        btn.style.backgroundColor = '#22c55e';
                        setTimeout(() => {
                            btn.innerHTML = window.i18n ? window.i18n.t('error_copy') : '📋 คัดลอกข้อมูลแจ้งปัญหา (Copy Log)';
                            btn.style.backgroundColor = '#ef4444';
                        }, 3000);
                    } catch (ex) {
                        btn.innerHTML = window.i18n ? window.i18n.t('error_copy_fail') : '❌ คัดลอกไม่สำเร็จ';
                    }
                    document.body.removeChild(textArea);
                });
            }
        }, 50);
    }

    window.addEventListener('error', function(event) {
        let msg = `Message: ${event.message}\n` +
                  `File: ${event.filename}\n` +
                  `Line: ${event.lineno}:${event.colno}\n`;
        if (event.error && event.error.stack) {
            msg += `\nStack Trace:\n${event.error.stack}`;
        }
        showErrorModal(msg);
    });

    window.addEventListener('unhandledrejection', function(event) {
        let msg = `Unhandled Promise Rejection\n`;
        if (event.reason) {
            msg += `Reason: ${event.reason.message || event.reason}\n`;
            if (event.reason.stack) {
                msg += `\nStack Trace:\n${event.reason.stack}`;
            }
        }
        showErrorModal(msg);
    });
})();

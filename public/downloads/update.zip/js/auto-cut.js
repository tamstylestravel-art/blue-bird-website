try {
    const { spawn } = require('child_process');
    const fs = require('fs');
    const path = require('path');
    const os = require('os');
    
    let wsInstance = null;
    let wsRegions = null;
    let currentProxyProcess = null;
    let currentFfmpegProcess = null;
    let currentSilences = [];
    let isAutoScrollEnabled = true;
    
    // JS based silence detection
    function detectSilencesJS(buffer, sampleRate, thresholdDb, minDurationSec, paddingSec) {
        const data = buffer.getChannelData(0); // Float32Array
        const thresholdAmp = Math.pow(10, thresholdDb / 20); // convert dB to amplitude (0.0 to 1.0)
        const minSamples = Math.floor(minDurationSec * sampleRate);
        const paddingSamples = Math.floor((paddingSec || 0) * sampleRate);
        
        let silences = [];
        let silenceStartSample = -1;
        let silenceSamplesCount = 0;
        
        function processSilenceChunk() {
            if (silenceSamplesCount >= minSamples) {
                let actualStart = silenceStartSample + paddingSamples;
                let actualEnd = (silenceStartSample + silenceSamplesCount) - paddingSamples;
                
                if (actualEnd > actualStart) {
                    silences.push({
                        start: actualStart / sampleRate,
                        end: actualEnd / sampleRate
                    });
                }
            }
        }
        
        for (let i = 0; i < data.length; i++) {
            if (Math.abs(data[i]) <= thresholdAmp) {
                if (silenceStartSample === -1) {
                    silenceStartSample = i;
                }
                silenceSamplesCount++;
            } else {
                processSilenceChunk();
                silenceStartSample = -1;
                silenceSamplesCount = 0;
            }
        }
        
        // Check if ends with silence
        processSilenceChunk();
        
        return silences;
    }
    
    function updateSliderBg(el) {
        if (!el || !el.max || !el.min) return;
        const value = (el.value - el.min) / (el.max - el.min) * 100;
        el.style.background = `linear-gradient(to right, #3b82f6 0%, #3b82f6 ${value}%, #000000 ${value}%, #000000 100%)`;
    }
    
    document.addEventListener('input', e => {
        if (e.target && e.target.matches && e.target.matches('#auto-cut-modal input[type="range"]')) {
            updateSliderBg(e.target);
        }
    });

    window.toggleAutoCutScroll = function() {
        isAutoScrollEnabled = !isAutoScrollEnabled;
        const btn = document.getElementById('autocut-autoscroll-btn');
        if (isAutoScrollEnabled) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
        if (wsInstance) {
            wsInstance.options.autoScroll = isAutoScrollEnabled;
        }
    };
    
    window.handleAutoCutZoomWheel = function(e) {
        e.preventDefault();
        const slider = document.getElementById('autocut-zoom-slider');
        let currentZoom = Number(slider.value);
        if (e.deltaY < 0) {
            currentZoom += 30; // zoom in
        } else {
            currentZoom -= 30; // zoom out
        }
        currentZoom = Math.max(10, Math.min(1000, currentZoom));
        slider.value = currentZoom;
        window.updateAutoCutZoom();
    };
    
    window.initAutoCutPreview = function() {
        const btn = document.getElementById('autocut-load-preview-btn');
        if (btn && btn.classList.contains('autocut-scan-btn-disabled')) {
            return;
        }
        
        if (wsInstance) window.destroyAutoCutPreview();
        
        // Initialize slider backgrounds
        updateSliderBg(document.getElementById('autocut-threshold-slider'));
        updateSliderBg(document.getElementById('autocut-duration-slider'));
        updateSliderBg(document.getElementById('autocut-padding-slider'));
        updateSliderBg(document.getElementById('autocut-zoom-slider'));
        
        // Show container immediately, hide load button
        const previewContainer = document.getElementById('autocut-preview-container');
        const settingsPanel = document.getElementById('autocut-settings-panel');
        const loadBtn = document.getElementById('autocut-load-preview-btn');
        const startBtn = document.getElementById('autocut-start-btn');
        if (previewContainer) previewContainer.style.display = 'flex';
        if (settingsPanel) settingsPanel.style.display = 'flex';
        if (loadBtn) loadBtn.style.display = 'none';
        if (startBtn) startBtn.style.display = 'block';
        
        const csInterface = new CSInterface();
        csInterface.evalScript('getSelectedClipAudioPath()', (result) => {
            if (!result || result === 'null' || result === '') {
                showError('กรุณาคลิกเลือกคลิปบน Timeline ก่อนครับ');
                if (loadBtn) loadBtn.style.display = 'block';
                return;
            }
            let clipInfo;
            try {
                clipInfo = JSON.parse(result);
            } catch(e) {
                clipInfo = { path: result, inPoint: 0, outPoint: 0 };
            }
            
            const filePath = clipInfo.path.replace(/\\/g, '/');
            if (!fs.existsSync(filePath)) {
                showError('ไม่พบไฟล์ต้นฉบับ: ' + filePath);
                if (loadBtn) loadBtn.style.display = 'block';
                return;
            }
            
            document.getElementById('autocut-waveform-loading').style.display = 'flex';
            document.getElementById('autocut-waveform-status').innerText = 'กำลังสกัดเสียงจำลอง...';
            document.getElementById('autocut-error-msg').style.display = 'none';
            
            const extPath = csInterface.getSystemPath(SystemPath.EXTENSION);
            const ffmpegPath = path.join(extPath, 'node_modules', 'ffmpeg-static', 'ffmpeg.exe');
            const proxyPath = path.join(os.tmpdir(), 'bluebird_autocut_proxy.wav');
            
            // Delete old proxy if exists
            if (fs.existsSync(proxyPath)) {
                try { fs.unlinkSync(proxyPath); } catch(e) {}
            }
            
            document.getElementById('autocut-waveform-status').innerText = 'กำลังสกัดเสียงจำลอง (1-3 วินาที)...';
            
            // Extract proxy: 16kHz mono wav, only for the trimmed portion
            const ffmpegArgs = ['-y'];
            if (clipInfo.inPoint > 0 || clipInfo.outPoint > 0) {
                ffmpegArgs.push('-ss', clipInfo.inPoint.toString());
                const duration = clipInfo.outPoint - clipInfo.inPoint;
                if (duration > 0) {
                    ffmpegArgs.push('-t', duration.toString());
                }
            }
            ffmpegArgs.push('-i', filePath, '-vn', '-ac', '1', '-ar', '16000', proxyPath);
            
            currentProxyProcess = spawn(ffmpegPath, ffmpegArgs);
            
            currentProxyProcess.on('close', (code) => {
                currentProxyProcess = null;
                if (code !== 0 && !fs.existsSync(proxyPath)) {
                    showError('เกิดข้อผิดพลาดในการดึงเสียง (FFmpeg Error)');
                    return;
                }
                
                document.getElementById('autocut-waveform-status').innerText = 'กำลังวาดเส้นเสียง...';
                
                // Initialize WaveSurfer
                wsInstance = window.WaveSurfer.create({
                    container: '#autocut-waveform',
                    waveColor: '#ffffff',
                    progressColor: '#0ea5e9',
                    cursorColor: '#fff',
                    barWidth: 2,
                    barRadius: 2,
                    height: 140,
                    normalize: true,
                    minPxPerSec: 50,
                    autoScroll: isAutoScrollEnabled,
                    plugins: [
                        window.WaveSurfer.Timeline.create({
                            container: '#autocut-timeline',
                            height: 20,
                            timeInterval: 10,
                            primaryLabelInterval: 10,
                            style: { fontSize: '10px', color: '#888' }
                        }),
                        window.WaveSurfer.Hover.create({
                            lineColor: 'rgba(255, 255, 255, 0.5)',
                            lineWidth: 2,
                            labelBackground: 'rgba(0, 0, 0, 0.5)',
                            labelColor: '#fff',
                            labelSize: '11px'
                        }),
                        window.WaveSurfer.Minimap.create({
                            container: '#autocut-minimap',
                            height: 35,
                            waveColor: '#555',
                            progressColor: '#888',
                            cursorColor: '#fff',
                            cursorWidth: 1,
                            overlayColor: 'rgba(0,0,0,0.4)',
                            interact: true
                        })
                    ]
                });
                
                wsRegions = wsInstance.registerPlugin(window.WaveSurfer.Regions.create());
                
                function addMinimapZoomHandles(ws) {
                    const minimapOverlay = document.querySelector('#autocut-minimap [part="minimap-overlay"]');
                    if (!minimapOverlay) return;
                    if (minimapOverlay.dataset.handlesAdded) return; // Prevent duplicate injection
                    minimapOverlay.dataset.handlesAdded = 'true';
                    
                    // Bring overlay to the front so the waveform doesn't block clicks!
                    minimapOverlay.parentNode.appendChild(minimapOverlay);
                    minimapOverlay.style.zIndex = '100';
                    
                    minimapOverlay.style.boxSizing = 'border-box';
                    minimapOverlay.style.borderTop = '2px solid #0078FF';
                    minimapOverlay.style.borderBottom = '2px solid #0078FF';
                    minimapOverlay.style.pointerEvents = 'auto'; // allow pointer events on the overlay so we can drag it
                    minimapOverlay.style.cursor = 'grab';
                    minimapOverlay.style.transition = 'none'; // Disable transition for smooth real-time dragging
                    
                    const handleStyle = 'position: absolute; top: 0; bottom: 0; width: 12px; background: #d4d4d4; cursor: ew-resize; z-index: 10; pointer-events: auto; display: flex; justify-content: center; align-items: center; box-sizing: border-box;';
                    const gripLines = '<div style="display: flex; gap: 2px;"><div style="width: 1px; height: 12px; background: #555;"></div><div style="width: 1px; height: 12px; background: #555;"></div></div>';
                    
                    let leftHandle = minimapOverlay.querySelector('.autocut-minimap-handle-left');
                    if (!leftHandle) {
                        leftHandle = document.createElement('div');
                        leftHandle.className = 'autocut-minimap-handle-left';
                        leftHandle.style.cssText = handleStyle + 'left: 0; border-right: 1px solid #0078FF; border-top-right-radius: 2px; border-bottom-right-radius: 2px;';
                        leftHandle.innerHTML = gripLines;
                        minimapOverlay.appendChild(leftHandle);
                    }
                    
                    let rightHandle = minimapOverlay.querySelector('.autocut-minimap-handle-right');
                    if (!rightHandle) {
                        rightHandle = document.createElement('div');
                        rightHandle.className = 'autocut-minimap-handle-right';
                        rightHandle.style.cssText = handleStyle + 'right: 0; border-left: 1px solid #0078FF; border-top-left-radius: 2px; border-bottom-left-radius: 2px;';
                        rightHandle.innerHTML = gripLines;
                        minimapOverlay.appendChild(rightHandle);
                    }
                    
                    let isDragging = false;
                    let startX = 0;
                    let startLeftPct = 0;
                    let startWidthPct = 0;
                    let updatePending = false;
                    const minimapContainer = document.querySelector('#autocut-minimap');

                    function onMouseDown(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        isDragging = true;
                        startX = e.clientX;
                        
                        const style = minimapOverlay.style;
                        startLeftPct = parseFloat(style.left) || 0;
                        startWidthPct = parseFloat(style.width) || 100;
                        
                        document.addEventListener('mousemove', onMouseMove);
                        document.addEventListener('mouseup', onMouseUp);
                        
                        document.body.style.cursor = 'grabbing';
                        minimapOverlay.style.cursor = 'grabbing';
                        
                        if (ws.options.autoScroll) {
                            ws.options.autoScroll = false;
                        }
                    }

                    function onMouseMove(e) {
                        if (!isDragging) return;
                        
                        const deltaX = e.clientX - startX;
                        const minimapWidth = minimapContainer.clientWidth;
                        const deltaPct = (deltaX / minimapWidth) * 100;
                        
                        let newLeftPct = startLeftPct + deltaPct;
                        
                        // Constraints for panning
                        if (newLeftPct < 0) {
                            newLeftPct = 0;
                        }
                        if (newLeftPct + startWidthPct > 100) {
                            newLeftPct = 100 - startWidthPct;
                        }
                        
                        // Optimistically update the UI immediately
                        minimapOverlay.style.left = newLeftPct + '%';
                        
                        // Throttle the actual wavesurfer scroll to prevent lag
                        if (!updatePending) {
                            updatePending = true;
                            requestAnimationFrame(() => {
                                if (!isDragging) {
                                    updatePending = false;
                                    return;
                                }
                                const totalDuration = ws.getDuration();
                                if (totalDuration) {
                                    ws.setScrollTime((newLeftPct / 100) * totalDuration);
                                }
                                updatePending = false;
                            });
                        }
                    }

                    function onMouseUp(e) {
                        isDragging = false;
                        document.removeEventListener('mousemove', onMouseMove);
                        document.removeEventListener('mouseup', onMouseUp);
                        document.body.style.cursor = 'default';
                        minimapOverlay.style.cursor = 'grab';
                        ws.options.autoScroll = typeof isAutoScrollEnabled !== 'undefined' ? isAutoScrollEnabled : true;
                        
                        // Trigger one final update to ensure it's synced perfectly
                        const finalLeftPct = parseFloat(minimapOverlay.style.left) || 0;
                        const totalDuration = ws.getDuration();
                        if (totalDuration) {
                            ws.setScrollTime((finalLeftPct / 100) * totalDuration);
                        }
                    }

                    minimapOverlay.addEventListener('mousedown', onMouseDown);
                    leftHandle.addEventListener('mousedown', onMouseDown);
                    rightHandle.addEventListener('mousedown', onMouseDown);
                }
                
                wsInstance.on('ready', () => {
                    document.getElementById('autocut-waveform-loading').style.display = 'none';
                    window.updateAutoCutLivePreview();
                    
                    // Add handles after a short delay to ensure minimap plugin has initialized its overlay
                    setTimeout(() => {
                        addMinimapZoomHandles(wsInstance);
                    }, 100);
                });
                
                wsInstance.on('play', () => {
                    const btn = document.getElementById('autocut-play-btn');
                    if (btn) {
                        btn.innerHTML = '&#10074;&#10074;'; // Heavy vertical bars for pause
                        btn.classList.add('active');
                    }
                });
                
                wsInstance.on('pause', () => {
                    const btn = document.getElementById('autocut-play-btn');
                    if (btn) {
                        btn.innerHTML = '▶';
                        btn.classList.remove('active');
                    }
                });
                
                wsInstance.on('error', (err) => {
                    showError('WaveSurfer Error: ' + err);
                });
                
                // Convert absolute path to file:// URL for WaveSurfer
                wsInstance.load('file:///' + proxyPath.replace(/\\/g, '/'));
            });
        });
    };
    
    window.updateAutoCutLivePreview = function() {
        const thresholdInput = document.getElementById('autocut-threshold-slider');
        const durationInput = document.getElementById('autocut-duration-slider');
        const paddingInput = document.getElementById('autocut-padding-slider');
        
        if (thresholdInput && durationInput && paddingInput) {
            document.getElementById('autocut-threshold-val').innerText = thresholdInput.value;
            document.getElementById('autocut-duration-val').innerText = durationInput.value;
            document.getElementById('autocut-padding-val').innerText = paddingInput.value;
        }
        
        if (!wsInstance || !wsRegions) return;
        
        const buffer = wsInstance.getDecodedData();
        if (!buffer) return;
        
        const threshold = parseFloat(thresholdInput.value);
        const duration = parseFloat(durationInput.value);
        const padding = parseFloat(paddingInput ? paddingInput.value : 0.2);
        
        currentSilences = detectSilencesJS(buffer, buffer.sampleRate, threshold, duration, padding);
        
        // Draw regions
        wsRegions.clearRegions();
        for (let s of currentSilences) {
            wsRegions.addRegion({
                start: s.start,
                end: s.end,
                color: 'rgba(239, 68, 68, 0.4)', // Red with opacity
                drag: false,
                resize: false
            });
        }
    };
    
    window.updateAutoCutZoom = function() {
        if (!wsInstance) return;
        const zoomSlider = document.getElementById('autocut-zoom-slider');
        const zoom = zoomSlider.value;
        if (typeof updateSliderBg === 'function') {
            updateSliderBg(zoomSlider);
        }
        wsInstance.zoom(Number(zoom));
    };
    
    window.playPauseAutoCutPreview = function() {
        if (wsInstance) {
            wsInstance.playPause();
        }
    };
    
    window.destroyAutoCutPreview = function() {
        if (currentProxyProcess) {
            currentProxyProcess.kill();
            currentProxyProcess = null;
        }
        if (wsInstance) {
            wsInstance.destroy();
            wsInstance = null;
            wsRegions = null;
        }
        document.getElementById('autocut-waveform').innerHTML = '';
        document.getElementById('autocut-timeline').innerHTML = '';
    };
    
    window.runAutoCutProcess = function() {
        if (currentSilences.length === 0) {
            alert('ไม่พบช่องว่าง (Dead Air) ในการตั้งค่านี้ ลองปรับให้ไวขึ้นครับ');
            return;
        }
        
        
        const ripple = document.getElementById('autocut-ripple').checked;
        const silencesJson = JSON.stringify(currentSilences);
        
        const csInterface = new CSInterface();
        
        // UI Updates for Processing
        document.getElementById('autocut-action-buttons').style.display = 'none';
        document.getElementById('autocut-cut-progress-area').style.display = 'flex';
        
        // Give UI a moment to render the progress bar before blocking ExtendScript thread
        setTimeout(() => {
            csInterface.evalScript(`applyAutoCut('${silencesJson}', ${ripple})`, (cutResult) => {
                document.getElementById('autocut-cut-progress-area').style.display = 'none';
                
                if (cutResult === 'success') {
                    const successAlert = document.getElementById('autocut-success-alert');
                    
                    successAlert.innerHTML = `
                        <div style="width: 60px; height: 60px; background: linear-gradient(135deg, #22c55e, #16a34a); border-radius: 50%; display: flex; justify-content: center; align-items: center; margin-bottom: 15px; box-shadow: 0 0 20px rgba(34, 197, 94, 0.5); animation: popIn 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);">
                            <span style="color: white; font-size: 30px;">✓</span>
                        </div>
                        <div style="color: white; font-size: 18px; font-weight: 500; font-family: 'Mitr', sans-serif; margin-bottom: 5px;">ตัดคลิปสำเร็จแล้ว!</div>
                        <div style="color: var(--text-light); font-size: 13px;">ลบช่องว่าง (Dead Air) เรียบร้อย</div>
                        <button onclick="closeAutoCutModal()" style="margin-top: 25px; padding: 10px 30px; background: linear-gradient(135deg, #8b5cf6, #c026d3); border: none; border-radius: 4px; color: white; cursor: pointer; font-family: 'Mitr', sans-serif; font-size: 15px; font-weight: 500; transition: 0.2s; box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3);">ตกลง (OK)</button>
                    `;
                    successAlert.style.display = 'flex';
                } else {
                    document.getElementById('autocut-action-buttons').style.display = 'flex';
                    alert('❌ เกิดข้อผิดพลาดในการตัดคลิป: ' + cutResult);
                }
            });
        }, 300);
    };
    
    function showError(msg) {
        document.getElementById('autocut-waveform-loading').style.display = 'none';
        const err = document.getElementById('autocut-error-msg');
        err.style.display = 'block';
        err.innerText = msg;
    }
    
    } catch(e) {
        alert("Error loading Auto Cut module: " + e.message + "\n" + e.stack);
    }

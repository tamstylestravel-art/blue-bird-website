// --- theme-manager.js ---

function syncThemeColor() {
            // โยนงานไปให้ระบบสีตัวใหม่ (Mister Horse Style) ทำงานแทน
            if (typeof applyCustomDarkTheme === 'function') {
                applyCustomDarkTheme();
            }
            
            // อัปเดตสีหลอดเสียงให้สวยงาม
            var volSlider = document.getElementById('volume-slider');
            if (volSlider && typeof updateSliderFill === 'function') {
                updateSliderFill(volSlider);
            }
        }

function applyCustomDarkTheme() {
            var skinInfo = myCsInterface.getHostEnvironment().appSkinInfo;
            var bg = skinInfo.panelBackgroundColor.color;
            
            var r = bg.red;
            var g = bg.green;
            var b = bg.blue;
            
            // เช็คว่า Premiere Pro ใช้ Theme สว่าง หรือ มืด (ค่าเฉลี่ยเกิน 128 คือสว่าง)
            var isDark = (r + g + b) / 3 < 128;
            
            if (isDark) {
                // 🚀 โหมดมืด: โค้ดลับดึงสีให้ "เข้มกว่าค่าเริ่มต้นของ Premiere" (สไตล์ Mister Horse)
                r = Math.max(0, r - 7);
                g = Math.max(0, g - 7);
                b = Math.max(0, b - 7);
                
                // บังคับตัวหนังสือขาว และเส้นขอบดำสนิท
                document.documentElement.style.setProperty('--text-color', '#ffffff');
                document.documentElement.style.setProperty('--text-light', '#b3b3b3');
                document.documentElement.style.setProperty('--border-color', '#000000');
                document.documentElement.style.setProperty('--border-light', '#000000');
            } else {
                // ☀️ โหมดสว่าง: ปล่อยให้สีสว่างตามปกติของโปรแกรม
                document.documentElement.style.setProperty('--text-color', '#000000');
                document.documentElement.style.setProperty('--text-light', '#555555');
                document.documentElement.style.setProperty('--border-color', '#aaaaaa');
                document.documentElement.style.setProperty('--border-light', '#cccccc');
            }
            
            // คำนวณเฉดสีของแต่ละส่วนประกอบให้มีมิติ
            var newMainBg = "rgb(" + r + "," + g + "," + b + ")"; // สีหลัก
            var newPanelBg = "rgb(" + Math.min(255, r + 5) + "," + Math.min(255, g + 5) + "," + Math.min(255, b + 5) + ")"; // แถบซ้ายสว่างขึ้นนิดนึง
            var newCardBg = "rgb(" + Math.min(255, r + 10) + "," + Math.min(255, g + 10) + "," + Math.min(255, b + 10) + ")"; // สีการ์ด
            var newHoverBg = "rgb(" + Math.min(255, r + 20) + "," + Math.min(255, g + 20) + "," + Math.min(255, b + 20) + ")"; // สีตอนเมาส์ชี้
            var newWaveformBg = "rgb(" + Math.max(0, r - 10) + "," + Math.max(0, g - 10) + "," + Math.max(0, b - 10) + ")"; // คลื่นเสียงดำสุด
            
            // ยัดสีที่คำนวณเสร็จกลับเข้าไปทับ CSS 
            document.documentElement.style.setProperty('--app-bg', newMainBg);
            document.documentElement.style.setProperty('--main-bg', newMainBg);
            document.documentElement.style.setProperty('--panel-bg', newPanelBg);
            document.documentElement.style.setProperty('--card-bg', newCardBg);
            document.documentElement.style.setProperty('--card-hover', newHoverBg);
            document.documentElement.style.setProperty('--waveform-bg', newWaveformBg);
        }

function toggleFavorite(fullPath, e) {
            if (e) e.stopPropagation();
            const isFav = favorites.includes(fullPath);
            if (isFav) {
                favorites = favorites.filter(f => f !== fullPath);
            } else {
                favorites.push(fullPath);
            }
            bluebirdStorage.setItem('bluebird_favorites', JSON.stringify(favorites));
            
            const safePath = fullPath.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            document.querySelectorAll(`span.star-icon`).forEach(el => {
                const onClickStr = el.getAttribute('onclick');
                if (onClickStr && onClickStr.includes(safePath)) {
                    if (isFav) el.classList.remove('active');
                    else el.classList.add('active');
                }
            });
            if (showOnlyFavorites && isFav) renderGrid(); 
        }

function toggleFavorite(fullPath, e) {
            if (e) e.stopPropagation();
            const isFav = favorites.includes(fullPath);
            if (isFav) {
                favorites = favorites.filter(f => f !== fullPath);
            } else {
                favorites.push(fullPath);
            }
            bluebirdStorage.setItem('bluebird_favorites', JSON.stringify(favorites));
            
            const safePath = fullPath.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            document.querySelectorAll(`span.star-icon`).forEach(el => {
                const onClickStr = el.getAttribute('onclick');
                if (onClickStr && onClickStr.includes(safePath)) {
                    if (isFav) el.classList.remove('active');
                    else el.classList.add('active');
                }
            });
            
            // ถ้ายกเลิกดาวตอนเปิดโหมดกรองดาวอยู่ ให้รีเฟรชหน้าจอแบบนุ่มนวล
            if (showOnlyFavorites && isFav) {
                loadSavedFolders(); 
                renderGrid(); 
            }
        }

function toggleFavFilter() {
            showOnlyFavorites = !showOnlyFavorites;
            const star = document.querySelector('#filter-fav-btn .star-icon');
            if (showOnlyFavorites) star.classList.add('active');
            else star.classList.remove('active');
            loadSavedFolders();
            renderGrid();
        }

function setFolderColor(color) {
            if(!contextTarget) return;
            if (color === '') {
                delete folderColors[contextTarget];
            } else {
                folderColors[contextTarget] = color;
            }
            const prefixWin = contextTarget + "\\";
            Object.keys(folderColors).forEach(key => {
                if (key.startsWith(prefixWin)) delete folderColors[key];
            });
            bluebirdStorage.setItem('bluebird_folder_colors', JSON.stringify(folderColors));
            
            // 🌟 เปลี่ยนสีลงไปที่แถบโฟลเดอร์โดยตรง (แก้บั๊กโฟลเดอร์เด้งกางเอง) 🌟
            document.querySelectorAll('.folder-label').forEach(label => {
                if(label.getAttribute('data-path') === contextTarget) {
                    if (color === '') {
                        label.style.setProperty('background-color', 'transparent', 'important');
                    } else {
                        let r = parseInt(color.slice(1, 3), 16);
                        let g = parseInt(color.slice(3, 5), 16);
                        let b = parseInt(color.slice(5, 7), 16);
                        label.style.setProperty('background-color', `rgba(${r}, ${g}, ${b}, 0.2)`, 'important');
                    }
                }
            });
            
            document.getElementById('context-menu').style.display = 'none';
        }

function setFolderColor(color) {
            if(!contextTarget) return;
            if (color === '') delete folderColors[contextTarget];
            else folderColors[contextTarget] = color;
            
            const prefixWin = contextTarget + "\\";
            Object.keys(folderColors).forEach(key => {
                if (key.startsWith(prefixWin)) delete folderColors[key];
            });
            bluebirdStorage.setItem('bluebird_folder_colors', JSON.stringify(folderColors));
            
            const safeTarget = contextTarget.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
            const targetLabel = document.querySelector(`.folder-label[data-path="${safeTarget}"]`);
            
            if (targetLabel) {
                const treeRoot = targetLabel.closest('.tree-root');
                let bgColor = 'transparent';
                let leftColor = 'transparent';
                
                if (color !== '') {
                    let r = parseInt(color.slice(1, 3), 16);
                    let g = parseInt(color.slice(3, 5), 16);
                    let b = parseInt(color.slice(5, 7), 16);
                    bgColor = `rgba(${r}, ${g}, ${b}, 0.2)`;
                    leftColor = color;
                }

                // สาดสีใส่โฟลเดอร์หลัก
                targetLabel.style.setProperty('background-color', bgColor, 'important');
                targetLabel.style.setProperty('border-left-color', leftColor, 'important');

                // สาดสีใส่เส้นแถบซ้ายให้โฟลเดอร์/ไฟล์ลูกๆ ข้างในทั้งหมดทันที
                if (treeRoot && targetLabel.parentElement === treeRoot) {
                    treeRoot.querySelectorAll('.folder-label, .file-label').forEach(el => {
                        if (el !== targetLabel) el.style.setProperty('border-left-color', leftColor, 'important');
                    });
                }
            }
            document.getElementById('context-menu').style.display = 'none';
        }


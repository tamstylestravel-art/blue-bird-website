// --- premiere-link.js ---

function importToPremiere(fullPath, isReversed = false) {
            try {
                csInterface.evalScript(`importFile("${fullPath.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}", ${isReversed})`);
            } catch(err) { alert("Error: " + err.message); }
        }

function addSelectedToTimeline() {
            if(!currentPlayingFile) return;
            const reverseCheck = document.getElementById('reverse-checkbox');
            const isReversed = reverseCheck ? reverseCheck.checked : false;
            importToPremiere(currentPlayingFile.fullPath, isReversed);
        }


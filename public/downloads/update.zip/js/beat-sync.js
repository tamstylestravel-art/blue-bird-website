// 🎬 Auto Beat Sync Logic

let beatSyncWsInstance = null;
let beatSyncWsRegions = null;
let beatSyncCurrentBeats = []; // Array of time in seconds
let beatSyncMode = 'bpm';
let beatSyncAudioCtx = null;
let beatSyncNextBeepIndex = 0;

function setBeatMode(mode) {
    beatSyncMode = mode;
    document.getElementById('beat-mode-bpm').classList.remove('active');
    document.getElementById('beat-mode-audio').classList.remove('active');
    
    document.getElementById('beat-bpm-controls').style.display = 'none';
    document.getElementById('beat-audio-controls').style.display = 'none';
    
    if (mode === 'bpm') {
        document.getElementById('beat-mode-bpm').classList.add('active');
        document.getElementById('beat-bpm-controls').style.display = 'block';
    } else {
        document.getElementById('beat-mode-audio').classList.add('active');
        document.getElementById('beat-audio-controls').style.display = 'block';
    }
    
    updateBeatSyncPreview();
}

function toggleBeatCutOptions() {
    const doCut = document.getElementById('beatsync-do-cut').checked;
    const cutOptions = document.getElementById('beatsync-cut-options');
    if (doCut) {
        cutOptions.style.opacity = '1';
        cutOptions.style.pointerEvents = 'auto';
    } else {
        cutOptions.style.opacity = '0.5';
        cutOptions.style.pointerEvents = 'none';
    }
}

function initBeatSyncPreview() {
    const csInterface = new CSInterface();
    const btn = document.getElementById('beatsync-scan-btn');
    const previewContainer = document.getElementById('beatsync-preview-container');
    const applyBtn = document.getElementById('beatsync-apply-btn');
    const loadingOverlay = document.getElementById('beatsync-loading-overlay');
    
    btn.innerText = 'กำลังสแกนคลิป (Scanning...)';
    btn.style.pointerEvents = 'none';
    btn.style.opacity = '0.5';
    
    previewContainer.style.display = 'block';
    loadingOverlay.style.display = 'flex';
    
    if (beatSyncWsInstance) {
        beatSyncWsInstance.destroy();
        beatSyncWsInstance = null;
        beatSyncWsRegions = null;
    }
    
    csInterface.evalScript('getSelectedClipAudioPath()', (result) => {
        if (!result || result === 'null' || result === '' || result.includes('Error')) {
            alert('ไม่พบคลิปที่เลือก หรือไม่สามารถดึงเสียงได้ กรุณาเลือกคลิปในไทม์ไลน์ก่อนครับ');
            btn.innerText = '🎵 โหลดเสียงเพื่อพรีวิว (Load Audio)';
            btn.style.pointerEvents = 'auto';
            btn.style.opacity = '1';
            loadingOverlay.style.display = 'none';
            return;
        }
        
        let clipInfo;
        try {
            clipInfo = JSON.parse(result);
        } catch(e) {
            clipInfo = { path: result, inPoint: 0, outPoint: 0 };
        }
        
        const fs = require('fs');
        const path = require('path');
        const os = require('os');
        const cp = require('child_process');
        
        const filePath = clipInfo.path.replace(/\\/g, '/');
        if (!fs.existsSync(filePath)) {
            alert('ไม่พบไฟล์ต้นฉบับ: ' + filePath);
            btn.innerText = '🎵 โหลดเสียงเพื่อพรีวิว (Load Audio)';
            btn.style.pointerEvents = 'auto';
            btn.style.opacity = '1';
            loadingOverlay.style.display = 'none';
            return;
        }
        
        const extPath = csInterface.getSystemPath(SystemPath.EXTENSION);
        const ffmpegPath = path.join(extPath, 'node_modules', 'ffmpeg-static', 'ffmpeg.exe');
        const proxyPath = path.join(os.tmpdir(), 'bluebird_beatsync_proxy.wav');
        
        if (fs.existsSync(proxyPath)) {
            try { fs.unlinkSync(proxyPath); } catch(e) {}
        }
        
        const ffmpegArgs = ['-y'];
        if (clipInfo.inPoint > 0 || clipInfo.outPoint > 0) {
            ffmpegArgs.push('-ss', clipInfo.inPoint.toString());
            if (clipInfo.outPoint > 0) {
                const dur = clipInfo.outPoint - clipInfo.inPoint;
                ffmpegArgs.push('-t', dur.toString());
            }
        }
        ffmpegArgs.push('-i', filePath, '-ac', '1', '-ar', '16000', proxyPath);
        
        cp.execFile(ffmpegPath, ffmpegArgs, (err) => {
            if (err) {
                alert('เกิดข้อผิดพลาดในการสกัดเสียง (ffmpeg): ' + err.message);
                btn.innerText = '🎵 โหลดเสียงเพื่อพรีวิว (Load Audio)';
                btn.style.pointerEvents = 'auto';
                btn.style.opacity = '1';
                loadingOverlay.style.display = 'none';
                return;
            }
            loadBeatSyncAudio('file:///' + proxyPath.replace(/\\/g, '/'), btn, loadingOverlay, applyBtn);
        });
    });
}

function loadBeatSyncAudio(audioPath, btn, loadingOverlay, applyBtn) {
    if (typeof WaveSurfer === 'undefined') {
        setTimeout(() => loadBeatSyncAudio(audioPath, btn, loadingOverlay, applyBtn), 500);
        return;
    }
    
    beatSyncWsInstance = WaveSurfer.create({
        container: '#beatsync-waveform',
        waveColor: '#f43f5e',
        progressColor: '#e11d48',
        cursorColor: '#ffffff',
        barWidth: 2,
        barRadius: 2,
        height: 120,
        normalize: true,
        interact: true
    });
    
    beatSyncWsInstance.load(audioPath);
    
    beatSyncWsInstance.on('ready', () => {
        beatSyncWsRegions = beatSyncWsInstance.registerPlugin(window.WaveSurfer.Regions.create());
        
        btn.innerText = '🎵 โหลดเสียงใหม่ (Reload)';
        btn.style.pointerEvents = 'auto';
        btn.style.opacity = '1';
        
        loadingOverlay.style.display = 'none';
        applyBtn.style.opacity = '1';
        applyBtn.style.pointerEvents = 'auto';
        
        const playBtn = document.getElementById('beatsync-play-btn');
        if (playBtn) {
            playBtn.style.display = 'block';
            playBtn.style.opacity = '1';
            playBtn.style.pointerEvents = 'auto';
            playBtn.innerText = '▶️ เล่นเสียง (Play)';
        }
        
        updateBeatSyncPreview();
    });
    
    beatSyncWsInstance.on('play', () => {
        const playBtn = document.getElementById('beatsync-play-btn');
        if (playBtn) playBtn.innerText = '⏸️ หยุด (Pause)';
        
        beatSyncNextBeepIndex = 0;
        const curTime = beatSyncWsInstance.getCurrentTime();
        for (let i = 0; i < beatSyncCurrentBeats.length; i++) {
            if (beatSyncCurrentBeats[i] >= curTime) {
                beatSyncNextBeepIndex = i;
                break;
            }
        }
    });
    
    beatSyncWsInstance.on('pause', () => {
        const playBtn = document.getElementById('beatsync-play-btn');
        if (playBtn) playBtn.innerText = '▶️ เล่นเสียง (Play)';
    });
    
    beatSyncWsInstance.on('audioprocess', (time) => {
        if (beatSyncNextBeepIndex < beatSyncCurrentBeats.length) {
            // Check if current time crossed the beat time
            if (time >= beatSyncCurrentBeats[beatSyncNextBeepIndex]) {
                playMetronomeBeep();
                beatSyncNextBeepIndex++;
            }
        }
    });
    
    beatSyncWsInstance.on('error', (err) => {
        alert('เกิดข้อผิดพลาดในการโหลด Waveform: ' + err);
        loadingOverlay.style.display = 'none';
    });
}

function updateBeatSyncPreview() {
    if (!beatSyncWsInstance) return;
    
    const buffer = beatSyncWsInstance.getDecodedData();
    if (!buffer) return;
    
    if (beatSyncMode === 'bpm') {
        const bpm = parseFloat(document.getElementById('beatsync-bpm-input').value) || 120;
        beatSyncCurrentBeats = detectBeatsBPM(buffer, bpm);
    } else {
        const sensInput = document.getElementById('beatsync-sens-slider');
        const sens = parseFloat(sensInput.value) || 50;
        document.getElementById('beatsync-sens-val').innerText = sens + '%';
        
        beatSyncCurrentBeats = detectBeatsAudio(buffer, sens);
    }
    
    // Draw markers on WaveSurfer
    if (beatSyncWsRegions) {
        beatSyncWsRegions.clearRegions();
        
        for (let time of beatSyncCurrentBeats) {
            beatSyncWsRegions.addRegion({
                start: time,
                end: time + 0.05,
                color: 'rgba(255, 255, 255, 0.4)',
                drag: false,
                resize: false
            });
        }
    }
}

function detectBeatsBPM(buffer, bpm) {
    const duration = buffer.duration;
    const bps = bpm / 60;
    const interval = 1 / bps;
    
    let beats = [];
    for (let t = 0; t < duration; t += interval) {
        beats.push(t);
    }
    return beats;
}

function detectBeatsAudio(buffer, sensitivity) {
    const origData = buffer.getChannelData(0);
    const sampleRate = buffer.sampleRate;
    
    // 1. Apply Low-Pass Filter (~150Hz) to isolate kick drum / heavy bass (Metronome focus)
    const cutoffFreq = 150;
    const rc = 1.0 / (cutoffFreq * 2 * Math.PI);
    const dt = 1.0 / sampleRate;
    const alpha = dt / (rc + dt);
    
    let data = new Float32Array(origData.length);
    data[0] = origData[0];
    for (let i = 1; i < origData.length; i++) {
        data[i] = data[i - 1] + (alpha * (origData[i] - data[i - 1]));
    }
    
    // 2. Normalize the filtered audio so the threshold applies consistently
    let maxAmp = 0.0001;
    for (let i = 0; i < data.length; i++) {
        let abs = Math.abs(data[i]);
        if (abs > maxAmp) maxAmp = abs;
    }
    for (let i = 0; i < data.length; i++) {
        data[i] /= maxAmp;
    }
    
    // 3. Peak Detection
    // threshold from 0.85 (lowest sens) to 0.15 (highest sens)
    const threshold = 0.85 - (0.7 * (sensitivity / 100));
    
    const minDistanceSamples = Math.floor(sampleRate * 0.2); // max ~300 BPM
    
    let beats = [];
    let lastBeatSample = -minDistanceSamples;
    
    const chunkSize = Math.floor(sampleRate * 0.01); // 10ms chunk
    for (let i = 0; i < data.length; i += chunkSize) {
        let maxVal = 0;
        let peakIndex = i;
        for (let j = 0; j < chunkSize && i + j < data.length; j++) {
            let val = Math.abs(data[i + j]);
            if (val > maxVal) {
                maxVal = val;
                peakIndex = i + j;
            }
        }
        
        if (maxVal > threshold) {
            if (peakIndex - lastBeatSample > minDistanceSamples) {
                beats.push({ time: peakIndex / sampleRate, strength: maxVal });
                lastBeatSample = peakIndex;
            } else {
                let lastBeat = beats[beats.length - 1];
                if (maxVal > lastBeat.strength) {
                    lastBeat.time = peakIndex / sampleRate;
                    lastBeat.strength = maxVal;
                    lastBeatSample = peakIndex;
                }
            }
        }
    }
    
    return beats.map(b => b.time);
}

function applyBeatSyncAction() {
    if (beatSyncCurrentBeats.length === 0) {
        alert('ไม่พบจังหวะ (Beat) เลย กรุณาปรับค่าใหม่ครับ');
        return;
    }
    
    const doMark = document.getElementById('beatsync-do-mark').checked;
    const doCut = document.getElementById('beatsync-do-cut').checked;
    const markColor = document.getElementById('beatsync-color').value;
    
    let cutAll = false;
    if (doCut) {
        const cutTypeRadios = document.getElementsByName('beat-cut-type');
        for (let r of cutTypeRadios) {
            if (r.checked && r.value === 'all') cutAll = true;
        }
    }
    
    const applyBtn = document.getElementById('beatsync-apply-btn');
    applyBtn.innerText = 'กำลังทำงาน...';
    applyBtn.style.pointerEvents = 'none';
    
    const beatsJson = JSON.stringify(beatSyncCurrentBeats);
    
    const csInterface = new CSInterface();
    csInterface.evalScript(`applyBeatSync('${beatsJson}', ${doMark}, ${doCut}, ${cutAll}, ${markColor})`, (result) => {
        applyBtn.innerText = '✨ สั่งทำงาน (Apply)';
        applyBtn.style.pointerEvents = 'auto';
        
        if (result === 'success') {
            closeBeatSyncModal();
        } else if (result.includes('Cut All Tracks API is not natively supported')) {
            alert('พี่หนึ่งครับ ตอนนี้ระบบ ExtendScript ของ Premiere Pro ยังไม่รองรับการสับมีดทุกแทร็กอัตโนมัติ 😅 \nแต่ระบบได้สร้าง Marker ไว้ให้เรียบร้อยแล้ว พี่หนึ่งสามารถเปิด Snap (ตัว S) แล้วใช้คัตเตอร์สับตามสี Marker ได้เลยครับ!');
            closeBeatSyncModal();
        } else {
            alert('เกิดข้อผิดพลาดในการรันคำสั่งบน Premiere Pro: ' + result);
        }
    });
}

function toggleBeatSyncPlay() {
    if (!beatSyncWsInstance) return;
    if (beatSyncWsInstance.isPlaying()) {
        beatSyncWsInstance.pause();
    } else {
        beatSyncWsInstance.play();
    }
}

function playMetronomeBeep() {
    try {
        if (!beatSyncAudioCtx) {
            beatSyncAudioCtx = new (window.AudioContext || window.webkitAudioContext)();
        }
        if (beatSyncAudioCtx.state === 'suspended') {
            beatSyncAudioCtx.resume();
        }
        const osc = beatSyncAudioCtx.createOscillator();
        const gain = beatSyncAudioCtx.createGain();
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, beatSyncAudioCtx.currentTime); // High pitch beep
        osc.frequency.exponentialRampToValueAtTime(100, beatSyncAudioCtx.currentTime + 0.1);
        
        gain.gain.setValueAtTime(0.5, beatSyncAudioCtx.currentTime); // Volume
        gain.gain.exponentialRampToValueAtTime(0.01, beatSyncAudioCtx.currentTime + 0.1);
        
        osc.connect(gain);
        gain.connect(beatSyncAudioCtx.destination);
        
        osc.start();
        osc.stop(beatSyncAudioCtx.currentTime + 0.1);
    } catch(e) {
        console.error("Metronome error:", e);
    }
}

function autoDetectBPM() {
    if (!beatSyncWsInstance) {
        alert('กรุณาโหลดเสียงเพื่อพรีวิวก่อนครับ');
        return;
    }
    const buffer = beatSyncWsInstance.getDecodedData();
    if (!buffer) {
        alert('กรุณาโหลดเสียงให้เสร็จสมบูรณ์ก่อนครับ');
        return;
    }
    
    // Use detectBeatsAudio with moderate sensitivity to grab main peaks
    const beats = detectBeatsAudio(buffer, 80);
    
    if (beats.length < 3) {
        alert('ไม่สามารถคำนวณ BPM ได้ (หาจังหวะในเพลงไม่ค่อยเจอครับ)');
        return;
    }
    
    let intervals = [];
    for (let i = 1; i < beats.length; i++) {
        intervals.push(beats[i] - beats[i - 1]);
    }
    
    let bpmCounts = {};
    for (let inter of intervals) {
        if (inter < 0.2) continue; // skip unrealistic intervals > 300bpm
        
        let bpm = Math.round(60 / inter);
        
        // Normalize to a common music range (70 - 150 BPM)
        while (bpm < 70) bpm *= 2;
        while (bpm > 150) bpm = Math.round(bpm / 2);
        
        // Group by bins of 2 BPM to tolerate slight timing variations
        let bin = Math.round(bpm / 2) * 2;
        bpmCounts[bin] = (bpmCounts[bin] || 0) + 1;
    }
    
    let bestBPM = 120;
    let maxCount = 0;
    for (let b in bpmCounts) {
        if (bpmCounts[b] > maxCount) {
            maxCount = bpmCounts[b];
            bestBPM = parseInt(b);
        }
    }
    
    document.getElementById('beatsync-bpm-input').value = bestBPM;
    updateBeatSyncPreview();
    
    // Flashing effect to show success
    const btn = document.getElementById('beatsync-bpm-input');
    const oldBg = btn.style.background;
    btn.style.background = '#166534';
    setTimeout(() => btn.style.background = oldBg, 300);
}

$ruleName = "Blue Bird Composer CEP Allow"

# 1. Remove existing rules (both block and allow) with this name
netsh advfirewall firewall delete rule name="$ruleName" | Out-Null

# Dynamically find all Adobe folders across all hard drives (C:\, D:\, E:\, etc.)
$searchPaths = @()
foreach ($drive in (Get-PSDrive -PSProvider FileSystem)) {
    $searchPaths += "$($drive.Root)Program Files\Adobe"
    $searchPaths += "$($drive.Root)Program Files (x86)\Adobe"
}

# 2. Allow CEPHtmlEngine in Windows Firewall
foreach ($searchPath in $searchPaths) {
    if (Test-Path $searchPath) {
        $paths = Get-ChildItem -Path $searchPath -Filter "CEPHtmlEngine.exe" -Recurse -ErrorAction SilentlyContinue
        foreach ($path in $paths) {
            $programPath = $path.FullName
            # Remove any specific block rules for this exact path
            netsh advfirewall firewall delete rule program="$programPath" | Out-Null
            
            # Add Allow rules
            netsh advfirewall firewall add rule name="$ruleName" dir=out action=allow program="$programPath" enable=yes profile=any | Out-Null
            netsh advfirewall firewall add rule name="$ruleName" dir=in action=allow program="$programPath" enable=yes profile=any | Out-Null
        }
    }
}

# 3. Prefer IPv4 over IPv6 globally (Solves the EACCES 2001:... issue without fully disabling IPv6)
# This changes the prefix policy so Windows resolves and connects to IPv4 first.
# ::ffff:0:0/96 is IPv4-mapped IPv6 (effectively IPv4). Precedence 46 is higher than ::/0 (IPv6) Precedence 40.
netsh interface ipv6 set prefixpolicy ::ffff:0:0/96 46 4 | Out-Null
netsh interface ipv6 set prefixpolicy ::/0 40 6 | Out-Null

[LangOptions]
LanguageName=ภาษาไทย (Thai)
LanguageID=$041E
LanguageCodePage=874
